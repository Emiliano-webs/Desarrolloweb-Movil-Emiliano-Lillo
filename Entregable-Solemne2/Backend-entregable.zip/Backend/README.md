# Bowling Health - Backend (Caso 21 · Evaluación Unidad 2)

Backend de 4 microservicios privados + 1 servicio de agregación GraphQL. Node.js + TypeScript + Express + PostgreSQL.
Cada servicio tiene su propia base de datos y valida el JWT por su cuenta. No hay API Gateway ni frontend (se evalúan aparte):
Postman llama directamente a cada servicio y simula los eventos de las pantallas P01 a P12.

| Servicio | Puerto | Servicios (S) | Base de datos |
|---|---|---|---|
| `clients` (auth + clientes + usuarios) | 3001 | S04 a S20 | `clients_db` (5433) |
| `inventory` | 3002 | S01 a S03, S34 a S38 | `inventory_db` (5432) |
| `orders` (pedidos, caja, despacho) | 3003 | S21 a S24, S27 a S32 | `orders_db` (5434) |
| `payments` | 3004 | S25, S25b, S26 | `payments_db` (5435) |
| `graphql` (agregación) | 3005 | S33, S39 | no tiene (solo llama a los demás) |

## 1. Instalación (primera vez)

Requisitos: Node.js 20.12 o superior, Docker Desktop abierto, Postman.

```powershell
cd Backend
docker compose down -v        # solo si ya tenías el contenedor db-inventory de antes (borra sus datos de prueba)
npm install
npm run keys                  # crea el archivo .env con claves aleatorias y muestra la contraseña del ADMIN
npm run db:up                 # levanta las 4 bases de datos
docker compose ps             # las 4 deben decir "healthy"
```

Si venías del avance anterior: borra `services/inventory/package.json`, `package-lock.json`, `tsconfig.json` y la carpeta
`node_modules` que estaban dentro de `services/inventory`, y la `node_modules` suelta de la raíz. Ahora hay UN solo `package.json` en `Backend`.

## 2. Iniciar los servicios

```powershell
npm run dev:all               # los 5 servicios juntos (Ctrl + C los detiene)
```

o uno por terminal: `npm run dev:clients`, `dev:inventory`, `dev:orders`, `dev:payments`, `dev:graphql`.
Comprobar: `http://localhost:3001/health` (y 3002 a 3005) debe responder `{"service":"...","status":"ok"}`.

Para detener todo: `Ctrl + C` y `npm run db:down` (agrega `-v` a `docker compose down` si quieres borrar también los datos).

## 3. Pruebas con Postman

1. Importa `postman/BowlingHealth.postman_collection.json` y `postman/local.postman_environment.json`.
2. En el entorno "Bowling Health local" completa **adminPassword** (la que mostró `npm run keys`, o `ADMIN_PASSWORD` del `.env`)
   y **webhookSecret** (`PAYMENT_WEBHOOK_SECRET` del `.env`). Selecciona ese entorno.
3. Ejecuta la colección completa con **Runner** (en orden) o por carpeta. Cada request trae sus tests (pestaña *Test Results*).
4. Por consola (opcional): `npm run test:e2e` (usa newman; completa los dos valores en `postman/local.postman_environment.json` antes).

Cada ejecución crea correos y RUN nuevos (variable `runId`), así que se puede repetir. El límite de reenvío de verificación (3 por hora por IP) puede responder 429 y el test lo acepta.

### Pruebas de validación pedidas en el Módulo 7

| # | Caso | Request en Postman | Resultado esperado | Quién lo verifica |
|---|---|---|---|---|
| 1 | Catálogo anónimo | 01 / S01, S02, S03 | 200 sin `stock` | Inventory |
| 2 | Operación protegida sin sesión | 08 / "Sin token" | 401 | middleware JWT de cada servicio |
| 3 | Administración con rol sin permiso | 06 / "Cliente crea producto" | 403 | Inventory (`requireRole`) |
| 4 | Pedido ajeno | 03 / "Pedido AJENO" y 07 / GraphQL ajeno | 404 / NOT_FOUND | Orders (consulta filtra por dueño) |
| 5 | Acceso directo al backend sin identidad | 08 / "/internal ... => 401" | 401 | `serviceAuth` de cada servicio |
| 6 | Confirmar pago con datos alterados | 03 / "Pago con monto", "Webhook firma inválida", "monto distinto" | 400 / 401 / AMOUNT_MISMATCH | Payments |

Otras: total enviado por el cliente (400), login sin verificar (403), token de verificación en la URL (400), RUN enmascarado, webhook repetido (no se reprocesa), venta duplicada (409), saltos de estado de despacho (409), anulación conservando el registro, último ADMIN protegido, límites GraphQL.

## 3b. Prueba de carga (Módulo 9)

```powershell
# 1) En .env: RATE_LIMIT_DISABLED=true   y   DEV_EXPOSE_TOKENS=true   (luego reinicia: npm run dev:all)
npm run load                      # 3 s de calentamiento + 30 s por escenario (5 escenarios)
npm run load -- --duration 60     # más duración
npm run load -- --only pedido     # un solo escenario: catalogo, detalle, graphql, reporte o pedido
npm run load:selftest             # comprueba el propio script (no necesita los servicios)
# 2) Al terminar, vuelve a poner RATE_LIMIT_DISABLED=false
```

El script prepara sus propios datos (producto, cliente, dirección y pedido) y deja `load-results.md` (tabla lista para el informe) y `load-results.json`.
Mide p50, p95 y p99 exactos, throughput, errores y CPU/memoria de la máquina. Cierra las demás aplicaciones pesadas durante la prueba y repítela 2 o 3 veces para ver la variación.

## 4. Controles de seguridad implementados

- **El servidor decide montos y estados:** Orders calcula el total con los precios reales de Inventory; el pago toma el monto del pedido; solo el webhook firmado mueve un pedido a `PAID`.
- **Contraseñas:** Argon2id. **RUN:** AES-256-GCM en la BD, índice ciego HMAC para búsqueda y unicidad, enmascarado en toda respuesta (`12.345.***-5`).
- **Sesiones:** JWT RS256 de 15 minutos firmado solo por `clients`; refresh token de 7 días guardado como hash, con rotación y revocación en logout.
- **Token de verificación de correo:** solo viaja en el body, se guarda como hash, un solo uso, vence a las 24 h.
- **Autorización:** rol por ruta y propiedad del recurso dentro de la consulta SQL (un pedido ajeno responde 404, no 403).
- **Servicios privados:** las rutas `/internal/*` exigen el `SERVICE_TOKEN`; un JWT de usuario no sirve ahí. Orders consulta a Inventory/Clients y Payments consulta a Orders con plazo máximo de 3 s y error controlado si no responden.
- **Webhook:** HMAC-SHA256 sobre `timestamp.cuerpo` con comparación en tiempo constante, tolerancia de 5 min, idempotencia por `eventId`, validación de monto y moneda.
- **GraphQL:** autenticación y autorización por resolver, DataLoader (sin N+1), límite de profundidad (5) y de campos (60), introspección desactivada con `NODE_ENV=production`, sin campo `run`, error parcial controlado si Inventory o Payments caen.
- **Generales:** lista blanca de campos (`zod .strict()`), límite de cuerpo 100 KB, rate limiting, `helmet`, `x-correlation-id` en cada log (sin cuerpos, contraseñas ni tokens), secretos solo en `.env` (ignorado por git).

## 5. Datos de prueba

Se cargan solos al iniciar: los 6 productos de tu menú + 2 de prueba (id 7 no disponible, id 8 con baja lógica) y 3 promos (2 vigentes y 1 vencida) en Inventory; el ADMIN inicial en Clients.
CAJERO y DESPACHO los crea la colección (S19). Un RUN válido de ejemplo: `12345678-5`.

## 6. Límites conocidos (decisiones simples, para declarar en el informe)

- El token de verificación se muestra en la consola y, con `DEV_EXPOSE_TOKENS=true`, en la respuesta (solo desarrollo; en producción iría por correo SMTP).
- El access token no se puede revocar antes de expirar (15 min); el logout y los cambios de rol/estado revocan los refresh tokens.
- Los usuarios internos reciben una contraseña temporal pero no hay un servicio para cambiarla (no está en los 39 servicios).
- La pasarela de pago es simulada: Postman actúa como el proveedor y firma los webhooks.
- No hay gateway ni TLS local: en una entrega real irían detrás del API Gateway con TLS.

## 7. Estructura

```
Backend/
  docker-compose.yml  .env.example  package.json  tsconfig.json
  scripts/gen-env.mjs         genera .env con claves
  shared/                     código común (JWT, errores, validación, llamadas entre servicios)
  services/clients|inventory|orders|payments|graphql/src
  postman/                    colección y entorno
```

## 8. Si algo falla

| Síntoma | Causa probable |
|---|---|
| `password authentication failed` | La BD se creó con otra clave: `docker compose down -v`, `npm run keys -- --force` (o `node scripts/gen-env.mjs --force`) y `npm run db:up` |
| `ECONNREFUSED ...:543x` | Docker Desktop cerrado o contenedor aún no `healthy` |
| `Falta la variable de entorno ...` | No existe `.env` (ejecuta `npm run keys`) o ejecutas `npm` fuera de la carpeta `Backend` |
| `Cannot find module 'argon2'` | Falta `npm install` en `Backend` |
| `npm run load` muestra 429 | Falta `RATE_LIMIT_DISABLED=true` en `.env` (y reiniciar los servicios) |
| 503 `DEPENDENCY_UNAVAILABLE` al crear un pedido | Algún servicio (clients/inventory) no está iniciado |
| Postman: 401 en todo | Falta ejecutar la carpeta 00 o `adminPassword` está vacío |
| Postman: `devToken` undefined | `DEV_EXPOSE_TOKENS=true` falta en el `.env`; reinicia `clients` |
