// Genera un .env con secretos aleatorios. Uso: npm run keys   (o: node scripts/gen-env.mjs --force)
import { generateKeyPairSync, randomBytes } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";

if (existsSync(".env") && !process.argv.includes("--force")) {
  console.log(".env ya existe. Usa --force para reemplazarlo (borra el actual).");
  process.exit(0);
}
const { privateKey, publicKey } = generateKeyPairSync("rsa", {
  modulusLength: 2048,
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
  publicKeyEncoding: { type: "spki", format: "pem" },
});
const b64 = (s) => Buffer.from(s).toString("base64");
const rnd = (n = 24) => randomBytes(n).toString("hex");
const adminPassword = "Admin-" + rnd(6) + "!";

let env = readFileSync(".env.example", "utf8");
const set = (key, value) => { env = env.replace(new RegExp(`^${key}=.*$`, "m"), `${key}=${value}`); };

for (const k of ["CLIENTS", "INVENTORY", "ORDERS", "PAYMENTS"]) set(`${k}_DB_PASSWORD`, rnd());
set("JWT_PRIVATE_KEY_B64", b64(privateKey));
set("JWT_PUBLIC_KEY_B64", b64(publicKey));
set("RUN_AES_KEY_B64", randomBytes(32).toString("base64"));
set("RUN_BLINDINDEX_KEY_B64", randomBytes(32).toString("base64"));
set("SERVICE_TOKEN", rnd(32));
set("PAYMENT_WEBHOOK_SECRET", rnd(32));
set("ADMIN_PASSWORD", adminPassword);

writeFileSync(".env", env);
console.log(".env creado.");
console.log("Admin inicial:  admin@bowlinghealth.cl  /  " + adminPassword);
console.log("Si ya tenías contenedores de base de datos con otra clave, ejecuta: docker compose down -v");
