
import { createServer } from "node:http";
import { writeFileSync } from "node:fs";
import { arch, cpus, freemem, platform, release, totalmem } from "node:os";
import { performance } from "node:perf_hooks";

try { process.loadEnvFile(".env"); } catch {  }

const args = process.argv.slice(2);
const opt = (name, def) => { const i = args.indexOf("--" + name); return i >= 0 ? args[i + 1] : def; };
const DURATION = Number(opt("duration", 30));   
const WARMUP = Number(opt("warmup", 3));       
const ONLY = opt("only", null);
const SELFTEST = args.includes("--selftest");

const U = {
  clients: process.env.CLIENTS_URL ?? "http://localhost:3001",
  inventory: process.env.INVENTORY_URL ?? "http://localhost:3002",
  orders: process.env.ORDERS_URL ?? "http://localhost:3003",
  payments: process.env.PAYMENTS_URL ?? "http://localhost:3004",
  graphql: `http://localhost:${process.env.GRAPHQL_PORT ?? 3005}`,
};

// ---------------------------------------------------------------- utilidades
async function call(method, url, { token, body } = {}) {
  const res = await fetch(url, {
    method,
    headers: { ...(body ? { "content-type": "application/json" } : {}), ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(15000),
  });
  let json = null;
  try { json = await res.json(); } catch { /* sin cuerpo */ }
  return { status: res.status, json };
}

function genRun() { // RUT chileno válido (módulo 11)
  const b = String(10000000 + Math.floor(Math.random() * 80000000));
  let s = 0, m = 2;
  for (let i = b.length - 1; i >= 0; i--) { s += Number(b[i]) * m; m = m === 7 ? 2 : m + 1; }
  const r = 11 - (s % 11);
  return b + "-" + (r === 11 ? "0" : r === 10 ? "K" : String(r));
}

const percentile = (sorted, q) => (sorted.length ? sorted[Math.min(sorted.length - 1, Math.max(0, Math.ceil(q * sorted.length) - 1))] : 0);

// CPU y memoria de TODA la máquina, muestreados por cada segundo
function startSampler() {
  const cpuTimes = () => cpus().reduce((a, c) => { const t = c.times; a.idle += t.idle; a.total += t.user + t.nice + t.sys + t.idle + t.irq; return a; }, { idle: 0, total: 0 });
  let prev = cpuTimes();
  const cpu = [], mem = [];
  const id = setInterval(() => {
    const now = cpuTimes();
    const dTotal = now.total - prev.total, dIdle = now.idle - prev.idle;
    if (dTotal > 0) cpu.push(100 * (1 - dIdle / dTotal));
    mem.push((totalmem() - freemem()) / 1024 ** 3);
    prev = now;
  }, 1000);
  return () => {
    clearInterval(id);
    const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
    return { cpuAvg: avg(cpu), cpuMax: Math.max(0, ...cpu), memAvg: avg(mem), memMax: Math.max(0, ...mem) };
  };
}

async function runScenario(sc) {
  const lat = [];
  let total = 0, errors = 0, limited = 0;
  const stopSampler = startSampler();
  const warmEnd = performance.now() + WARMUP * 1000;
  const end = warmEnd + DURATION * 1000;

  async function worker() {
    while (performance.now() < end) {
      const r = sc.make();
      const t0 = performance.now();
      let status = 0, ok = false;
      try {
        const res = await fetch(r.url, {
          method: r.method,
          headers: { ...(r.body ? { "content-type": "application/json" } : {}), ...(r.token ? { authorization: `Bearer ${r.token}` } : {}) },
          body: r.body ? JSON.stringify(r.body) : undefined,
          signal: AbortSignal.timeout(15000),
        });
        status = res.status;
        const text = await res.text();
        ok = (sc.ok ?? [200]).includes(status) && (!sc.checkBody || sc.checkBody(text));
      } catch { status = 0; }
      const t1 = performance.now();
      if (t0 >= warmEnd) { // solo cuenta lo medido después del calentamiento
        total++; lat.push(t1 - t0);
        if (!ok) { errors++; if (status === 429) limited++; }
      }
    }
  }
  await Promise.all(Array.from({ length: sc.conns }, worker));
  const elapsed = Math.max(0.001, (performance.now() - warmEnd) / 1000);
  const sys = stopSampler();
  lat.sort((a, b) => a - b);
  const p95 = percentile(lat, 0.95);
  const errPct = total ? (100 * errors) / total : 100;
  return {
    id: sc.id, name: sc.name, conns: sc.conns, duration: DURATION, requests: total, rps: total / elapsed,
    avg: lat.length ? lat.reduce((a, b) => a + b, 0) / lat.length : 0,
    p50: percentile(lat, 0.5), p95, p99: percentile(lat, 0.99), max: lat.length ? lat[lat.length - 1] : 0,
    errors, errPct, limited, ...sys, objective: sc.objective, meets: total > 0 && p95 <= sc.objective && errPct < 1,
  };
}

// ---------------------------------------------------------------- preparación de datos
async function setup() {
  const health = await Promise.all(Object.entries(U).map(async ([n, u]) => {
    try { return [n, (await fetch(u + "/health", { signal: AbortSignal.timeout(3000) })).ok]; } catch { return [n, false]; }
  }));
  const down = health.filter(([, ok]) => !ok).map(([n]) => n);
  if (down.length) throw new Error(`Estos servicios no responden: ${down.join(", ")}. Inícialos con: npm run dev:all`);

  const admin = await call("POST", `${U.clients}/auth/login`, { body: { email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD } });
  if (admin.status !== 200) throw new Error("No se pudo iniciar sesión como ADMIN (revisa ADMIN_EMAIL y ADMIN_PASSWORD en .env)");
  const adminToken = admin.json.accessToken;

  const stamp = Date.now();
  const prod = await call("POST", `${U.inventory}/admin/products`, {
    token: adminToken,
    body: { name: `Producto de carga ${stamp}`, description: "Producto para la prueba de carga", price: 5000, stock: 100000, category: "bowls" },
  });
  if (prod.status !== 201) throw new Error("No se pudo crear el producto de prueba");

  const email = `carga${stamp}@correo.cl`, password = "Clave-Carga-2026!";
  const reg = await call("POST", `${U.clients}/auth/register`, { body: { email, password, name: "Cliente Carga", run: genRun(), phone: "+56911112222" } });
  if (!reg.json?.devToken) throw new Error("El registro no devolvió devToken: pon DEV_EXPOSE_TOKENS=true en .env y reinicia clients");
  const ver = await call("POST", `${U.clients}/auth/verify-email`, { body: { email, token: reg.json.devToken } });
  if (ver.status !== 200) throw new Error("No se pudo verificar el cliente de prueba");
  const login = await call("POST", `${U.clients}/auth/login`, { body: { email, password } });
  const clientToken = login.json.accessToken;
  const addr = await call("POST", `${U.clients}/clients/me/addresses`, { token: clientToken, body: { alias: "Carga", street: "Av. Providencia", number: "1234", commune: "Providencia", city: "Santiago" } });
  const order = await call("POST", `${U.orders}/orders`, { token: clientToken, body: { addressId: addr.json.id, items: [{ productId: prod.json.id, quantity: 1 }] } });
  if (order.status !== 201) throw new Error("No se pudo crear el pedido de prueba");
  return { adminToken, clientToken, addressId: addr.json.id, productId: prod.json.id, orderId: order.json.id };
}

function buildScenarios(ctx) {
  const query = "query($id: ID!){ orderDetail(id:$id){ id status total items{ name quantity unitPrice product{ currentPrice available } } payment{ status } } }";
  const desde = new Date(Date.now() - 30 * 86400000).toISOString(), hasta = new Date().toISOString();
  return [
    { id: "catalogo", name: "Catálogo S01 (GET /products)", conns: 20, objective: 300, make: () => ({ method: "GET", url: `${U.inventory}/products` }) },
    { id: "detalle", name: "Detalle de producto S02 (GET /products/1)", conns: 20, objective: 300, make: () => ({ method: "GET", url: `${U.inventory}/products/1` }) },
    { id: "graphql", name: "Detalle de pedido GraphQL S39 (Orders+Inventory+Payments)", conns: 10, objective: 800,
      checkBody: (t) => !t.includes('"errors"'),
      make: () => ({ method: "POST", url: `${U.graphql}/graphql`, token: ctx.clientToken, body: { query, variables: { id: ctx.orderId } } }) },
    { id: "reporte", name: "Reporte de ventas S33 (GET /reports/sales)", conns: 5, objective: 800,
      make: () => ({ method: "GET", url: `${U.graphql}/reports/sales?desde=${encodeURIComponent(desde)}&hasta=${encodeURIComponent(hasta)}`, token: ctx.adminToken }) },
    { id: "pedido", name: "Crear pedido S21 (POST /orders, escritura)", conns: 5, objective: 800, ok: [201],
      make: () => ({ method: "POST", url: `${U.orders}/orders`, token: ctx.clientToken, body: { addressId: ctx.addressId, items: [{ productId: ctx.productId, quantity: 1 }] } }) },
  ];
}

// ---------------------------------------------------------------- salida
const f = (n, d = 0) => Number(n).toFixed(d);
function report(results) {
  const cpu = cpus();
  const env = [
    `Fecha: ${new Date().toISOString()}`,
    `Equipo: ${cpu[0]?.model?.trim()} (${cpu.length} hilos), ${f(totalmem() / 1024 ** 3, 1)} GB de RAM, ${platform()} ${release()} ${arch()}`,
    `Software: Node ${process.version}; los 5 servicios y las 4 bases de datos (Docker) en la misma máquina`,
    `Método: ${WARMUP} s de calentamiento (no se mide) + ${DURATION} s medidos por escenario; conexiones simultáneas según la tabla`,
    `Tipo de datos: MEDICIÓN (no proyección). Límite de peticiones por minuto desactivado durante la prueba (RATE_LIMIT_DISABLED=true)`,
    `CPU y memoria: de toda la máquina (servicios + Docker + este script), muestreados cada segundo`,
  ];
  let md = "# Resultados de la prueba de carga\n\n" + env.map((l) => `- ${l}`).join("\n") + "\n\n";
  md += "| Escenario | Conexiones | Solicitudes | Throughput (req/s) | p50 (ms) | p95 (ms) | p99 (ms) | Errores | CPU prom / máx (%) | Memoria prom / máx (GB) | Objetivo p95 (ms) | ¿Cumple? |\n|---|---|---|---|---|---|---|---|---|---|---|---|\n";
  for (const r of results)
    md += `| ${r.name} | ${r.conns} | ${r.requests} | ${f(r.rps, 1)} | ${f(r.p50)} | ${f(r.p95)} | ${f(r.p99)} | ${r.errors} (${f(r.errPct, 2)}%) | ${f(r.cpuAvg)} / ${f(r.cpuMax)} | ${f(r.memAvg, 1)} / ${f(r.memMax, 1)} | < ${r.objective} | ${r.meets ? "Sí" : "No"} |\n`;
  writeFileSync("load-results.md", md);
  writeFileSync("load-results.json", JSON.stringify({ environment: env, results }, null, 2));

  console.log("\n" + env.join("\n") + "\n");
  console.table(results.map((r) => ({
    Escenario: r.id, Conex: r.conns, Solicitudes: r.requests, "req/s": +f(r.rps, 1), "p50 ms": +f(r.p50), "p95 ms": +f(r.p95), "p99 ms": +f(r.p99),
    Errores: `${r.errors} (${f(r.errPct, 1)}%)`, "CPU% prom/máx": `${f(r.cpuAvg)}/${f(r.cpuMax)}`, "Mem GB": `${f(r.memAvg, 1)}/${f(r.memMax, 1)}`, "Objetivo": `<${r.objective}`, Cumple: r.meets ? "Sí" : "No",
  })));
  if (results.some((r) => r.limited > 0))
    console.log("\nATENCIÓN: hubo respuestas 429 (límite de peticiones). Pon RATE_LIMIT_DISABLED=true en .env, reinicia los servicios y repite la prueba.");
  console.log("\nGuardado: load-results.md (tabla para pegar en el informe) y load-results.json");
}

// ---------------------------------------------------------------- ejecución
async function main() {
  if (SELFTEST) { // servidor de mentira para comprobar que el script mide bien
    const server = createServer((_req, res) => setTimeout(() => { res.setHeader("content-type", "application/json"); res.end('{"ok":true}'); }, 20));
    await new Promise((r) => server.listen(0, r));
    const url = `http://localhost:${server.address().port}`;
    const r = await runScenario({ id: "selftest", name: "Servidor de mentira (20 ms por respuesta)", conns: 5, objective: 200, make: () => ({ method: "GET", url }) });
    server.close();
    console.log(`selftest: ${r.requests} solicitudes, ${f(r.rps, 1)} req/s, p50 ${f(r.p50)} ms, p95 ${f(r.p95)} ms, errores ${r.errors}`);
    const sane = r.requests > 50 && r.errors === 0 && r.p50 >= 18 && r.p95 < 200;
    console.log(sane ? "selftest OK" : "selftest FALLÓ");
    process.exit(sane ? 0 : 1);
  }
  console.log("Preparando datos de prueba (producto, cliente, dirección y pedido)...");
  const ctx = await setup();
  const scenarios = buildScenarios(ctx).filter((s) => !ONLY || s.id === ONLY);
  if (!scenarios.length) throw new Error(`Escenario desconocido: ${ONLY}`);
  const results = [];
  for (const sc of scenarios) {
    console.log(`\n>> ${sc.name}: ${sc.conns} conexiones, ${WARMUP} s de calentamiento + ${DURATION} s medidos`);
    const r = await runScenario(sc);
    console.log(`   ${r.requests} solicitudes, ${f(r.rps, 1)} req/s, p95 ${f(r.p95)} ms, errores ${r.errors}`);
    results.push(r);
  }
  report(results);
}
main().catch((e) => { console.error("\nERROR:", e.message); process.exit(1); });