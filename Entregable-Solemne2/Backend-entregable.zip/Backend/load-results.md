# Resultados de la prueba de carga

- Fecha: 2026-11-08T00:43:33.487Z
- Equipo: 13th Gen Intel(R) Core(TM) i5-13420H (12 hilos), 23.7 GB de RAM, win32 10.0.26200 x64
- Software: Node v26.13.0; los 5 servicios y las 4 bases de datos (Docker) en la misma máquina
- Método: 3 s de calentamiento (no se mide) + 30 s medidos por escenario; conexiones simultáneas según la tabla
- Tipo de datos: MEDICIÓN (no proyección). Límite de peticiones por minuto desactivado durante la prueba (RATE_LIMIT_DISABLED=true)
- CPU y memoria: de toda la máquina (servicios + Docker + este script), muestreados cada segundo

| Escenario | Conexiones | Solicitudes | Throughput (req/s) | p50 (ms) | p95 (ms) | p99 (ms) | Errores | CPU prom / máx (%) | Memoria prom / máx (GB) | Objetivo p95 (ms) | ¿Cumple? |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Catálogo S01 (GET /products) | 20 | 68648 | 2287.6 | 7 | 16 | 23 | 0 (0.00%) | 68 / 82 | 16.1 / 16.4 | < 300 | Sí |
| Detalle de producto S02 (GET /products/1) | 20 | 60811 | 2026.6 | 9 | 17 | 25 | 0 (0.00%) | 46 / 53 | 16.3 / 16.5 | < 300 | Sí |
| Detalle de pedido GraphQL S39 (Orders+Inventory+Payments) | 10 | 5908 | 196.8 | 47 | 93 | 160 | 0 (0.00%) | 67 / 78 | 16.5 / 16.7 | < 800 | Sí |
| Reporte de ventas S33 (GET /reports/sales) | 5 | 14355 | 478.3 | 8 | 25 | 39 | 0 (0.00%) | 65 / 82 | 16.5 / 16.9 | < 800 | Sí |
| Crear pedido S21 (POST /orders, escritura) | 5 | 1901 | 63.2 | 73 | 120 | 222 | 0 (0.00%) | 62 / 72 | 16.6 / 16.7 | < 800 | Sí |
