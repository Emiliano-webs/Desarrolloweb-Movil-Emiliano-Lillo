import { randomUUID } from "node:crypto";
import { createPool, waitForDb } from "@shared/db";
import { hashPassword } from "./security";

export const pool = createPool("CLIENTS");

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id                   UUID PRIMARY KEY,
  email                TEXT NOT NULL UNIQUE,
  name                 TEXT NOT NULL,
  password_hash        TEXT,
  role                 TEXT NOT NULL CHECK (role IN ('CLIENTE','ADMIN','CAJERO','DESPACHO')),
  status               TEXT NOT NULL CHECK (status IN ('PENDING_VERIFICATION','ACTIVE','DISABLED')),
  failed_attempts      INTEGER NOT NULL DEFAULT 0,
  locked_until         TIMESTAMPTZ,
  must_change_password BOOLEAN NOT NULL DEFAULT false,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS clients (
  id              UUID PRIMARY KEY REFERENCES users(id),
  phone           TEXT NOT NULL,
  run_encrypted   BYTEA NOT NULL,
  run_blind_index TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS addresses (
  id        UUID PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES clients(id),
  alias     TEXT NOT NULL,
  street    TEXT NOT NULL,
  number    TEXT NOT NULL,
  commune   TEXT NOT NULL,
  city      TEXT NOT NULL,
  notes     TEXT
);
CREATE TABLE IF NOT EXISTS verification_tokens (
  id         UUID PRIMARY KEY,
  user_id    UUID NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at    TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id         UUID PRIMARY KEY,
  user_id    UUID NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
`;

export async function initDb() {
  await waitForDb(pool);
  await pool.query(SCHEMA);
  await seedAdmin();
}

// Crea el primer administrador desde las variables ADMIN_EMAIL / ADMIN_PASSWORD (solo si no hay ninguno)
async function seedAdmin() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password) return;
  const { rowCount } = await pool.query("SELECT 1 FROM users WHERE role = 'ADMIN' LIMIT 1");
  if (rowCount) return;
  await pool.query(
    "INSERT INTO users (id, email, name, password_hash, role, status) VALUES ($1,$2,$3,$4,'ADMIN','ACTIVE')",
    [randomUUID(), email.toLowerCase(), "Administrador", await hashPassword(password)]
  );
  console.log(`Administrador inicial creado: ${email}`);
}
