import { randomBytes, randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { authenticate } from "@shared/auth";
import { HttpError, asyncHandler } from "@shared/errors";
import { limiter } from "@shared/http";
import { tx } from "@shared/db";
import { validate } from "@shared/validate";
import { pool } from "../db";
import { blindIndex, encryptRun, hashPassword, normalizeRun, sha256, verifyPassword } from "../security";
import { createVerificationToken, deliverToken, issueTokens } from "../tokens";

export const authRouter = Router();

const email = z.string().trim().toLowerCase().email().max(254);
const password = z.string().min(10, "La contraseña debe tener al menos 10 caracteres").max(128);
const GENERIC = { message: "Si el correo es válido, recibirás instrucciones para verificar tu cuenta." };
const invalidCredentials = () => new HttpError(401, "INVALID_CREDENTIALS", "Correo o contraseña incorrectos");

// Hash de relleno: el login tarda lo mismo exista o no el correo (evita enumerar cuentas por tiempo)
let dummyHash = "";
hashPassword(randomBytes(8).toString("hex")).then((h) => (dummyHash = h));

authRouter.use(limiter(60_000, 60)); // 60 por minuto por IP en todo /auth

// ---------- S04 Registro ----------
const registerSchema = z
  .object({
    email,
    password,
    name: z.string().trim().min(2).max(100),
    run: z.string().min(8).max(12),
    phone: z.string().regex(/^\+?[0-9]{8,15}$/, "Teléfono inválido"),
  })
  .strict(); // rechaza role, status, etc.

authRouter.post(
  "/register",
  validate(registerSchema),
  asyncHandler(async (req, res) => {
    const b = req.body;
    const run = normalizeRun(b.run);
    if (!run) throw new HttpError(400, "INVALID_RUN", "RUN inválido");
    const passwordHash = await hashPassword(b.password);
    const bi = blindIndex(run);

    const dup = await pool.query(
      "SELECT 1 FROM users WHERE email = $1 UNION ALL SELECT 1 FROM clients WHERE run_blind_index = $2",
      [b.email, bi]
    );
    if (dup.rowCount) return res.status(202).json(GENERIC); // misma respuesta: no revela si el correo/RUN existe

    const id = randomUUID();
    let token: string;
    try {
      token = await tx(pool, async (c) => {
        await c.query(
          "INSERT INTO users (id,email,name,password_hash,role,status) VALUES ($1,$2,$3,$4,'CLIENTE','PENDING_VERIFICATION')",
          [id, b.email, b.name, passwordHash]
        );
        await c.query("INSERT INTO clients (id,phone,run_encrypted,run_blind_index) VALUES ($1,$2,$3,$4)", [
          id,
          b.phone,
          encryptRun(run),
          bi,
        ]);
        return createVerificationToken(c, id);
      });
    } catch (e: any) {
      if (e?.code === "23505") return res.status(202).json(GENERIC);
      throw e;
    }
    res.status(202).json({ ...GENERIC, ...deliverToken(b.email, token) });
  })
);

// ---------- S05 Verificar correo (token en el body, nunca en la URL) ----------
const verifySchema = z.object({ email, token: z.string().min(20).max(100), password: password.optional() }).strict();

authRouter.post(
  "/verify-email",
  validate(verifySchema),
  asyncHandler(async (req, res) => {
    const { email: mail, token, password: pw } = req.body;
    const invalid = new HttpError(400, "INVALID_TOKEN", "Token inválido o expirado");

    const u = await pool.query("SELECT id, status, password_hash FROM users WHERE email = $1", [mail]);
    const user = u.rows[0];
    if (!user || user.status !== "PENDING_VERIFICATION") throw invalid;

    const t = await pool.query(
      `SELECT id FROM verification_tokens
       WHERE user_id = $1 AND token_hash = $2 AND used_at IS NULL AND expires_at > now()`,
      [user.id, sha256(token)]
    );
    if (!t.rowCount) throw invalid;

    // Cliente creado por el administrador: aún no tiene contraseña, la define aquí
    let newHash: string | null = null;
    if (!user.password_hash) {
      if (!pw) throw new HttpError(400, "PASSWORD_REQUIRED", "Debes definir una contraseña (mínimo 10 caracteres)");
      newHash = await hashPassword(pw);
    }
    await tx(pool, async (c) => {
      await c.query("UPDATE verification_tokens SET used_at = now() WHERE id = $1", [t.rows[0].id]);
      await c.query("UPDATE users SET status = 'ACTIVE', password_hash = COALESCE($2, password_hash) WHERE id = $1", [
        user.id,
        newHash,
      ]);
    });
    res.json({ status: "VERIFIED" });
  })
);

// ---------- S06 Reenviar verificación (3 por hora por IP y por correo) ----------
const resendSchema = z.object({ email }).strict();
const resendByIp = limiter(3_600_000, 3);
const resendByEmail = limiter(3_600_000, 3, (req) => "email:" + String(req.body?.email ?? "").toLowerCase());

authRouter.post(
  "/resend-verification",
  resendByIp,
  validate(resendSchema),
  resendByEmail,
  asyncHandler(async (req, res) => {
    const u = await pool.query("SELECT id, status FROM users WHERE email = $1", [req.body.email]);
    const user = u.rows[0];
    if (!user || user.status !== "PENDING_VERIFICATION") return res.status(202).json(GENERIC);
    const token = await createVerificationToken(pool, user.id);
    res.status(202).json({ ...GENERIC, ...deliverToken(req.body.email, token) });
  })
);

// ---------- S07 Login ----------
const loginSchema = z.object({ email, password: z.string().min(1).max(128) }).strict();

authRouter.post(
  "/login",
  validate(loginSchema),
  asyncHandler(async (req, res) => {
    const { email: mail, password: pw } = req.body;
    const { rows } = await pool.query("SELECT * FROM users WHERE email = $1", [mail]);
    const user = rows[0];

    if (!user || !user.password_hash) {
      await verifyPassword(dummyHash, pw);
      throw invalidCredentials();
    }
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      throw new HttpError(429, "ACCOUNT_LOCKED", "Cuenta bloqueada temporalmente por intentos fallidos. Intenta más tarde.");
    }
    if (!(await verifyPassword(user.password_hash, pw))) {
      await pool.query(
        `UPDATE users SET failed_attempts = failed_attempts + 1,
           locked_until = CASE WHEN failed_attempts + 1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END
         WHERE id = $1`,
        [user.id]
      );
      throw invalidCredentials();
    }
    // La contraseña es correcta: recién ahora se informa el estado de la cuenta
    if (user.status === "PENDING_VERIFICATION")
      throw new HttpError(403, "EMAIL_NOT_VERIFIED", "Debes verificar tu correo antes de iniciar sesión.");
    if (user.status === "DISABLED") throw new HttpError(403, "ACCOUNT_DISABLED", "Cuenta deshabilitada");

    await pool.query("UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = $1", [user.id]);
    const tokens = await issueTokens(pool, user);
    res.json({ ...tokens, role: user.role, mustChangePassword: user.must_change_password });
  })
);

// ---------- S08 Renovar token (el refresh usado queda invalidado: rotación) ----------
const refreshSchema = z.object({ refreshToken: z.string().min(10).max(200) }).strict();

authRouter.post(
  "/refresh",
  validate(refreshSchema),
  asyncHandler(async (req, res) => {
    const unauthorized = new HttpError(401, "INVALID_REFRESH_TOKEN", "Refresh token inválido o expirado");
    const { rows } = await pool.query(
      `SELECT r.id, u.id AS user_id, u.role, u.status
       FROM refresh_tokens r JOIN users u ON u.id = r.user_id
       WHERE r.token_hash = $1 AND r.revoked_at IS NULL AND r.expires_at > now()`,
      [sha256(req.body.refreshToken)]
    );
    const row = rows[0];
    if (!row || row.status !== "ACTIVE") throw unauthorized;

    const tokens = await tx(pool, async (c) => {
      await c.query("UPDATE refresh_tokens SET revoked_at = now() WHERE id = $1", [row.id]);
      return issueTokens(c, { id: row.user_id, role: row.role });
    });
    res.json({ ...tokens, role: row.role });
  })
);

// ---------- S09 Cerrar sesión (revoca el refresh token; el access expira solo a los 15 min) ----------
authRouter.post(
  "/logout",
  authenticate,
  validate(refreshSchema),
  asyncHandler(async (req, res) => {
    await pool.query(
      "UPDATE refresh_tokens SET revoked_at = now() WHERE token_hash = $1 AND user_id = $2 AND revoked_at IS NULL",
      [sha256(req.body.refreshToken), req.user!.sub]
    );
    res.status(204).end(); // idempotente
  })
);
