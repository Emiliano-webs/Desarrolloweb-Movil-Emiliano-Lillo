import { randomBytes, randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { authenticate, requireRole } from "@shared/auth";
import { HttpError, asyncHandler, conflict, notFound } from "@shared/errors";
import { tx } from "@shared/db";
import { pageQuery, validate } from "@shared/validate";
import { pool } from "../db";
import { blindIndex, encryptRun, hashPassword, maskEncryptedRun, normalizeRun } from "../security";
import { createVerificationToken, deliverToken } from "../tokens";

export const adminRouter = Router();
adminRouter.use(authenticate, requireRole("ADMIN"));

const uuidParam = validate(z.object({ id: z.string().uuid() }), "params");
const email = z.string().trim().toLowerCase().email().max(254);
const phone = z.string().regex(/^\+?[0-9]{8,15}$/, "Teléfono inválido");

const clientDto = (r: any) => ({
  id: r.id,
  name: r.name,
  email: r.email,
  phone: r.phone,
  runMasked: maskEncryptedRun(r.run_encrypted), // el RUN completo nunca sale del servicio
  status: r.status,
});
const CLIENT_SELECT = `SELECT u.id, u.name, u.email, u.status, c.phone, c.run_encrypted
                       FROM users u JOIN clients c ON c.id = u.id`;

// ---------- S15 Buscar clientes ----------
adminRouter.get(
  "/clients",
  validate(z.object({ q: z.string().trim().min(1).max(100).optional(), ...pageQuery }).strict(), "query"),
  asyncHandler(async (req, res) => {
    const { q, page, size } = req.query as any;
    const params: unknown[] = [];
    let where = "TRUE";
    if (q) {
      const like = "%" + q.replace(/[\\%_]/g, (m: string) => "\\" + m) + "%";
      const run = normalizeRun(q);
      params.push(like);
      let cond = `u.name ILIKE $${params.length} OR u.email ILIKE $${params.length}`;
      if (run) {
        params.push(blindIndex(run)); // búsqueda por RUN sin descifrar la tabla
        cond += ` OR c.run_blind_index = $${params.length}`;
      }
      where = `(${cond})`;
    }
    const total = await pool.query(`SELECT COUNT(*)::int AS n FROM users u JOIN clients c ON c.id = u.id WHERE ${where}`, params);
    params.push(size, (page - 1) * size);
    const { rows } = await pool.query(
      `${CLIENT_SELECT} WHERE ${where} ORDER BY u.created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    res.json({ items: rows.map(clientDto), page, size, total: total.rows[0].n });
  })
);

// ---------- S16 Registrar cliente presencial (el cliente define su contraseña al verificar el correo) ----------
const createClientSchema = z
  .object({ email, name: z.string().trim().min(2).max(100), run: z.string().min(8).max(12), phone })
  .strict();

adminRouter.post(
  "/clients",
  validate(createClientSchema),
  asyncHandler(async (req, res) => {
    const b = req.body;
    const run = normalizeRun(b.run);
    if (!run) throw new HttpError(400, "INVALID_RUN", "RUN inválido");
    const bi = blindIndex(run);
    const dup = await pool.query(
      "SELECT 1 FROM users WHERE email = $1 UNION ALL SELECT 1 FROM clients WHERE run_blind_index = $2",
      [b.email, bi]
    );
    if (dup.rowCount) throw conflict("CONFLICT", "Ya existe un cliente con ese correo o RUN");

    const id = randomUUID();
    const token = await tx(pool, async (c) => {
      await c.query("INSERT INTO users (id,email,name,role,status) VALUES ($1,$2,$3,'CLIENTE','PENDING_VERIFICATION')", [id, b.email, b.name]);
      await c.query("INSERT INTO clients (id,phone,run_encrypted,run_blind_index) VALUES ($1,$2,$3,$4)", [id, b.phone, encryptRun(run), bi]);
      return createVerificationToken(c, id);
    });
    const { rows } = await pool.query(`${CLIENT_SELECT} WHERE u.id = $1`, [id]);
    res.status(201).json({ ...clientDto(rows[0]), ...deliverToken(b.email, token) });
  })
);

// ---------- S17 Editar cliente (único lugar donde se corrige el RUN) ----------
const updateClientSchema = z
  .object({
    name: z.string().trim().min(2).max(100).optional(),
    phone: phone.optional(),
    run: z.string().min(8).max(12).optional(),
    status: z.enum(["ACTIVE", "DISABLED"]).optional(),
  })
  .strict()
  .refine((v) => Object.keys(v).length > 0, "Debes enviar al menos un campo");

adminRouter.put(
  "/clients/:id",
  uuidParam,
  validate(updateClientSchema),
  asyncHandler(async (req, res) => {
    const id = req.params.id;
    const b = req.body;
    const cur = await pool.query("SELECT u.status, u.password_hash FROM users u JOIN clients c ON c.id = u.id WHERE u.id = $1", [id]);
    if (!cur.rows[0]) throw notFound("Cliente no encontrado");

    let run: string | null = null;
    if (b.run !== undefined) {
      run = normalizeRun(b.run);
      if (!run) throw new HttpError(400, "INVALID_RUN", "RUN inválido");
      const dup = await pool.query("SELECT 1 FROM clients WHERE run_blind_index = $1 AND id <> $2", [blindIndex(run), id]);
      if (dup.rowCount) throw conflict("CONFLICT", "Ya existe otro cliente con ese RUN");
    }
    if (b.status === "ACTIVE" && !cur.rows[0].password_hash)
      throw conflict("INVALID_STATE", "El cliente aún no verifica su correo ni define su contraseña");

    await tx(pool, async (c) => {
      if (b.name !== undefined) await c.query("UPDATE users SET name = $2 WHERE id = $1", [id, b.name]);
      if (b.phone !== undefined) await c.query("UPDATE clients SET phone = $2 WHERE id = $1", [id, b.phone]);
      if (run) await c.query("UPDATE clients SET run_encrypted = $2, run_blind_index = $3 WHERE id = $1", [id, encryptRun(run), blindIndex(run)]);
      if (b.status !== undefined) {
        await c.query("UPDATE users SET status = $2 WHERE id = $1", [id, b.status]);
        if (b.status === "DISABLED") await c.query("UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL", [id]);
      }
    });
    const { rows } = await pool.query(`${CLIENT_SELECT} WHERE u.id = $1`, [id]);
    res.json(clientDto(rows[0]));
  })
);

// ---------- S18 Listar usuarios internos ----------
adminRouter.get(
  "/users",
  validate(
    z.object({ role: z.enum(["ADMIN", "CAJERO", "DESPACHO"]).optional(), status: z.enum(["ACTIVE", "DISABLED", "PENDING_VERIFICATION"]).optional(), ...pageQuery }).strict(),
    "query"
  ),
  asyncHandler(async (req, res) => {
    const { role, status, page, size } = req.query as any;
    const params: unknown[] = [];
    let where = "role <> 'CLIENTE'";
    if (role) { params.push(role); where += ` AND role = $${params.length}`; }
    if (status) { params.push(status); where += ` AND status = $${params.length}`; }
    const total = await pool.query(`SELECT COUNT(*)::int AS n FROM users WHERE ${where}`, params);
    params.push(size, (page - 1) * size);
    const { rows } = await pool.query(
      `SELECT id, email, name, role, status FROM users WHERE ${where} ORDER BY created_at LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    ); // nunca se devuelve password_hash
    res.json({ items: rows, page, size, total: total.rows[0].n });
  })
);

// ---------- S19 Crear usuario interno ----------
const createUserSchema = z.object({ email, name: z.string().trim().min(2).max(100), role: z.enum(["ADMIN", "CAJERO", "DESPACHO"]) }).strict();

adminRouter.post(
  "/users",
  validate(createUserSchema),
  asyncHandler(async (req, res) => {
    const b = req.body;
    // Contraseña temporal generada por el servidor (cumple mínimo 10 caracteres); el usuario debe cambiarla
    const temp = randomBytes(12).toString("base64url") + "aA1!";
    const id = randomUUID();
    const dup = await pool.query("SELECT 1 FROM users WHERE email = $1", [b.email]);
    if (dup.rowCount) throw conflict("CONFLICT", "Ya existe un usuario con ese correo");
    await pool.query(
      "INSERT INTO users (id,email,name,password_hash,role,status,must_change_password) VALUES ($1,$2,$3,$4,$5,'ACTIVE',true)",
      [id, b.email, b.name, await hashPassword(temp), b.role]
    );
    const devPassword =
      process.env.DEV_EXPOSE_TOKENS === "true" && process.env.NODE_ENV !== "production" ? { temporaryPassword: temp } : {};
    if (devPassword.temporaryPassword) console.log(`[DEV] Contraseña temporal de ${b.email}: ${temp}`);
    res.status(201).json({ id, email: b.email, name: b.name, role: b.role, status: "ACTIVE", mustChangePassword: true, ...devPassword });
  })
);

// ---------- S20 Editar rol/estado (no existe DELETE) ----------
const updateUserSchema = z
  .object({ role: z.enum(["ADMIN", "CAJERO", "DESPACHO"]).optional(), status: z.enum(["ACTIVE", "DISABLED"]).optional() })
  .strict()
  .refine((v) => v.role !== undefined || v.status !== undefined, "Debes enviar role o status");

adminRouter.put(
  "/users/:id",
  uuidParam,
  validate(updateUserSchema),
  asyncHandler(async (req, res) => {
    const id = req.params.id;
    const b = req.body;
    const out = await tx(pool, async (c) => {
      const cur = await c.query("SELECT id, role, status FROM users WHERE id = $1 AND role <> 'CLIENTE' FOR UPDATE", [id]);
      const user = cur.rows[0];
      if (!user) throw notFound("Usuario no encontrado");

      const losesAdmin = user.role === "ADMIN" && user.status === "ACTIVE" && ((b.role && b.role !== "ADMIN") || b.status === "DISABLED");
      if (losesAdmin) {
        const n = await c.query("SELECT COUNT(*)::int AS n FROM users WHERE role = 'ADMIN' AND status = 'ACTIVE'");
        if (n.rows[0].n <= 1) throw conflict("LAST_ADMIN", "No se puede deshabilitar ni degradar al último administrador");
      }
      const role = b.role ?? user.role;
      const status = b.status ?? user.status;
      await c.query("UPDATE users SET role = $2, status = $3 WHERE id = $1", [id, role, status]);
      // Al cambiar rol o estado se cierran sus sesiones (refresh tokens)
      await c.query("UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL", [id]);
      const { rows } = await c.query("SELECT id, email, name, role, status FROM users WHERE id = $1", [id]);
      return rows[0];
    });
    res.json(out);
  })
);
