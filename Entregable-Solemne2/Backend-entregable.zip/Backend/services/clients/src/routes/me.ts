import { randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { authenticate, requireRole } from "@shared/auth";
import { HttpError, asyncHandler, notFound } from "@shared/errors";
import { validate } from "@shared/validate";
import { pool } from "../db";
import { maskEncryptedRun } from "../security";

export const meRouter = Router();
// Todo /clients/me/*: solo rol CLIENTE. La identidad sale SIEMPRE del JWT (sub), nunca de la URL ni del body.
meRouter.use(authenticate, requireRole("CLIENTE"));

const profile = async (id: string) => {
  const { rows } = await pool.query(
    "SELECT u.id, u.name, u.email, c.phone, c.run_encrypted FROM users u JOIN clients c ON c.id = u.id WHERE u.id = $1",
    [id]
  );
  if (!rows[0]) throw notFound("Perfil no encontrado");
  const r = rows[0];
  return { id: r.id, name: r.name, email: r.email, phone: r.phone, runMasked: maskEncryptedRun(r.run_encrypted) };
};

// S10
meRouter.get("/", asyncHandler(async (req, res) => res.json(await profile(req.user!.sub))));

// S11 (no permite cambiar run, email, role ni status)
const updateSchema = z
  .object({ name: z.string().trim().min(2).max(100).optional(), phone: z.string().regex(/^\+?[0-9]{8,15}$/).optional() })
  .strict()
  .refine((v) => v.name !== undefined || v.phone !== undefined, "Debes enviar name o phone");

meRouter.put(
  "/",
  validate(updateSchema),
  asyncHandler(async (req, res) => {
    const id = req.user!.sub;
    if (req.body.name !== undefined) await pool.query("UPDATE users SET name = $2 WHERE id = $1", [id, req.body.name]);
    if (req.body.phone !== undefined) await pool.query("UPDATE clients SET phone = $2 WHERE id = $1", [id, req.body.phone]);
    res.json(await profile(id));
  })
);

// ---------- Direcciones ----------
const COLS = "id, alias, street, number, commune, city, notes";

// S12
meRouter.get(
  "/addresses",
  asyncHandler(async (req, res) => {
    const { rows } = await pool.query(`SELECT ${COLS} FROM addresses WHERE client_id = $1 ORDER BY alias`, [req.user!.sub]);
    res.json(rows);
  })
);

// S13
const addressSchema = z
  .object({
    alias: z.string().trim().min(1).max(40),
    street: z.string().trim().min(2).max(100),
    number: z.string().trim().min(1).max(10),
    commune: z.string().trim().min(2).max(60),
    city: z.string().trim().min(2).max(60),
    notes: z.string().trim().max(200).optional(),
  })
  .strict();

meRouter.post(
  "/addresses",
  validate(addressSchema),
  asyncHandler(async (req, res) => {
    const clientId = req.user!.sub; // lo fija el servidor
    const n = await pool.query("SELECT COUNT(*)::int AS n FROM addresses WHERE client_id = $1", [clientId]);
    if (n.rows[0].n >= 10) throw new HttpError(409, "LIMIT_REACHED", "Máximo 10 direcciones por cliente");
    const b = req.body;
    const { rows } = await pool.query(
      `INSERT INTO addresses (id, client_id, alias, street, number, commune, city, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING ${COLS}`,
      [randomUUID(), clientId, b.alias, b.street, b.number, b.commune, b.city, b.notes ?? null]
    );
    res.status(201).json(rows[0]);
  })
);

// S14 (Orders guarda una copia de la dirección en cada pedido, por eso se puede borrar siempre)
meRouter.delete(
  "/addresses/:id",
  validate(z.object({ id: z.string().uuid() }), "params"),
  asyncHandler(async (req, res) => {
    const r = await pool.query("DELETE FROM addresses WHERE id = $1 AND client_id = $2", [req.params.id, req.user!.sub]);
    if (!r.rowCount) throw notFound("Dirección no encontrada"); // 404 también si es de otro cliente
    res.status(204).end();
  })
);
