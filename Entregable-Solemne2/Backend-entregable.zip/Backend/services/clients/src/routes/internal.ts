import { Router } from "express";
import { z } from "zod";
import { serviceAuth } from "@shared/auth";
import { asyncHandler, notFound } from "@shared/errors";
import { validate } from "@shared/validate";
import { pool } from "../db";
import { maskEncryptedRun } from "../security";

// Rutas privadas: solo otros servicios con token de servicio. Auth nunca entrega el RUN completo.
export const internalRouter = Router();
internalRouter.use(serviceAuth);

const uuid = z.string().uuid();

// Orders (S21): ¿la dirección es de este cliente? -> dirección o 404
internalRouter.get(
  "/clients/:clientId/addresses/:addressId",
  validate(z.object({ clientId: uuid, addressId: uuid }), "params"),
  asyncHandler(async (req, res) => {
    const { rows } = await pool.query(
      "SELECT alias, street, number, commune, city, notes FROM addresses WHERE id = $1 AND client_id = $2",
      [req.params.addressId, req.params.clientId]
    );
    if (!rows[0]) throw notFound("Dirección no encontrada");
    res.json(rows[0]);
  })
);

// Orders (S27, S29): nombre y RUN enmascarado de varios clientes
internalRouter.get(
  "/clients/summaries",
  asyncHandler(async (req, res) => {
    const ids = String(req.query.ids ?? "").split(",").filter((s) => uuid.safeParse(s).success).slice(0, 50);
    if (ids.length === 0) return res.json([]);
    const { rows } = await pool.query(
      "SELECT u.id, u.name, c.run_encrypted FROM users u JOIN clients c ON c.id = u.id WHERE u.id = ANY($1::uuid[])",
      [ids]
    );
    res.json(rows.map((r) => ({ id: r.id, name: r.name, runMasked: maskEncryptedRun(r.run_encrypted) })));
  })
);
