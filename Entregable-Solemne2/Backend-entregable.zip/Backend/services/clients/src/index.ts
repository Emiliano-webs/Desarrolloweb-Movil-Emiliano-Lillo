import "@shared/env";
import { env } from "@shared/env";
import { createApp, finish } from "@shared/http";
import { initDb } from "./db";
import { assertKeys } from "./security";
import { adminRouter } from "./routes/admin";
import { authRouter } from "./routes/auth";
import { internalRouter } from "./routes/internal";
import { meRouter } from "./routes/me";

assertKeys();
const app = createApp("clients");

app.use("/auth", authRouter); // S04 a S09
app.use("/clients/me", meRouter); // S10 a S14
app.use("/admin", adminRouter); // S15 a S20
app.use("/internal", internalRouter); // privado: solo servicios
finish(app);

const PORT = Number(env("CLIENTS_PORT", "3001"));
initDb()
  .then(() => app.listen(PORT, () => console.log(`Clients escuchando en http://localhost:${PORT}`)))
  .catch((e) => {
    console.error("No se pudo iniciar Clients:", e.message);
    process.exit(1);
  });
