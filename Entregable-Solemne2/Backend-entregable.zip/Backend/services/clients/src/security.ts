import "@shared/env";
import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes } from "node:crypto";
import { argon2id, hash, verify } from "argon2";
import { env } from "@shared/env";

const aesKey = () => Buffer.from(env("RUN_AES_KEY_B64"), "base64");
const blindKey = () => Buffer.from(env("RUN_BLINDINDEX_KEY_B64"), "base64");

export function assertKeys() {
  if (aesKey().length !== 32) throw new Error("RUN_AES_KEY_B64 debe ser de 32 bytes (AES-256)");
  if (blindKey().length < 32) throw new Error("RUN_BLINDINDEX_KEY_B64 debe ser de al menos 32 bytes");
}

// ---- Contraseñas: hash adaptativo Argon2id (con sal incluida en el hash) ----
export const hashPassword = (plain: string) =>
  hash(plain, { type: argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
export const verifyPassword = (hashed: string, plain: string) => verify(hashed, plain).catch(() => false);

// ---- RUN: cifrado AES-256-GCM (iv | tag | texto cifrado) + índice ciego HMAC para unicidad y búsqueda ----
export function encryptRun(run: string): Buffer {
  const iv = randomBytes(12);
  const c = createCipheriv("aes-256-gcm", aesKey(), iv);
  const ct = Buffer.concat([c.update(run, "utf8"), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]);
}
export function decryptRun(buf: Buffer): string {
  const d = createDecipheriv("aes-256-gcm", aesKey(), buf.subarray(0, 12));
  d.setAuthTag(buf.subarray(12, 28));
  return Buffer.concat([d.update(buf.subarray(28)), d.final()]).toString("utf8");
}
export const blindIndex = (canonicalRun: string) => createHmac("sha256", blindKey()).update(canonicalRun).digest("hex");

// Devuelve "12345678-5" si el RUN es válido (módulo 11), o null
export function normalizeRun(input: string): string | null {
  const clean = input.replace(/[.\s-]/g, "").toUpperCase();
  if (!/^\d{7,8}[\dK]$/.test(clean)) return null;
  const body = clean.slice(0, -1);
  const dv = clean.slice(-1);
  let sum = 0;
  let mul = 2;
  for (let i = body.length - 1; i >= 0; i--) {
    sum += Number(body[i]) * mul;
    mul = mul === 7 ? 2 : mul + 1;
  }
  const r = 11 - (sum % 11);
  const expected = r === 11 ? "0" : r === 10 ? "K" : String(r);
  return dv === expected ? `${body}-${dv}` : null;
}

// "12345678-5" -> "12.345.***-5"
export function maskRun(canonical: string): string {
  const [body, dv] = canonical.split("-");
  const groups = body.replace(/\B(?=(\d{3})+(?!\d))/g, ".").split(".");
  groups[groups.length - 1] = "***";
  return `${groups.join(".")}-${dv}`;
}
export function maskEncryptedRun(buf: Buffer): string {
  try {
    return maskRun(decryptRun(buf));
  } catch {
    return "***";
  }
}

// ---- Tokens aleatorios (verificación, refresh): se guardan solo como hash SHA-256 ----
export const newToken = () => randomBytes(32).toString("base64url");
export const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");
