import { randomUUID } from "node:crypto";
import jwt from "jsonwebtoken";
import type { Pool, PoolClient } from "pg";
import { env } from "@shared/env";
import { newToken, sha256 } from "./security";

export const ACCESS_TTL_SECONDS = 900; // 15 minutos
const privateKey = () => Buffer.from(env("JWT_PRIVATE_KEY_B64"), "base64").toString("utf8");

export async function issueTokens(db: Pool | PoolClient, user: { id: string; role: string }) {
  // Solo este servicio posee la clave privada; los demás verifican con la pública
  const accessToken = jwt.sign({ role: user.role, jti: randomUUID() }, privateKey(), {
    algorithm: "RS256",
    subject: user.id,
    issuer: "clients-service",
    expiresIn: ACCESS_TTL_SECONDS,
  });
  const refreshToken = "rt_" + newToken();
  await db.query(
    "INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at) VALUES ($1,$2,$3, now() + interval '7 days')",
    [randomUUID(), user.id, sha256(refreshToken)]
  );
  return { accessToken, refreshToken, expiresIn: ACCESS_TTL_SECONDS };
}

// Crea un token de verificación de correo (invalida los anteriores). Devuelve el valor en claro SOLO para enviarlo.
export async function createVerificationToken(db: Pool | PoolClient, userId: string): Promise<string> {
  const token = newToken();
  await db.query("UPDATE verification_tokens SET used_at = now() WHERE user_id = $1 AND used_at IS NULL", [userId]);
  await db.query(
    "INSERT INTO verification_tokens (id, user_id, token_hash, expires_at) VALUES ($1,$2,$3, now() + interval '24 hours')",
    [randomUUID(), userId, sha256(token)]
  );
  return token;
}

// Entrega del token: en producción iría por correo (SMTP). En desarrollo se muestra en consola y,
// si DEV_EXPOSE_TOKENS=true, también en la respuesta para poder probar con Postman.
export function deliverToken(email: string, token: string): Record<string, string> {
  if (process.env.DEV_EXPOSE_TOKENS === "true" && process.env.NODE_ENV !== "production") {
    console.log(`[DEV] Token de verificación para ${email}: ${token}`);
    return { devToken: token };
  }
  return {};
}
