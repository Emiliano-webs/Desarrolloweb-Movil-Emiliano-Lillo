import { createPool, tx, waitForDb } from "@shared/db";
import { products, promos } from "./data";

export const pool = createPool("INVENTORY");

const SCHEMA = `
CREATE TABLE IF NOT EXISTS products (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT NOT NULL,
  price       INTEGER NOT NULL CHECK (price > 0),
  stock       INTEGER NOT NULL CHECK (stock >= 0),
  category    TEXT NOT NULL,
  image_url   TEXT,
  available   BOOLEAN NOT NULL DEFAULT true,
  deleted_at  TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS promos (
  id           TEXT PRIMARY KEY,
  title        TEXT NOT NULL,
  description  TEXT NOT NULL,
  discount_pct INTEGER NOT NULL CHECK (discount_pct BETWEEN 1 AND 100),
  image_url    TEXT,
  valid_from   TIMESTAMPTZ NOT NULL,
  valid_to     TIMESTAMPTZ NOT NULL
);
CREATE TABLE IF NOT EXISTS promo_products (
  promo_id   TEXT NOT NULL REFERENCES promos(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  PRIMARY KEY (promo_id, product_id)
);
-- Stock apartado por pedido: permite devolverlo si el pedido se anula
CREATE TABLE IF NOT EXISTS stock_reservations (
  id          SERIAL PRIMARY KEY,
  order_id    TEXT NOT NULL,
  product_id  INTEGER NOT NULL REFERENCES products(id),
  quantity    INTEGER NOT NULL CHECK (quantity > 0),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  released_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_reservations_order ON stock_reservations(order_id);
`;

export async function initDb() {
  await waitForDb(pool);
  await pool.query(SCHEMA);
  const { rows } = await pool.query("SELECT COUNT(*)::int AS n FROM products");
  if (rows[0].n > 0) return;

  await tx(pool, async (c) => {
    for (const p of products) {
      await c.query(
        `INSERT INTO products (id,name,description,price,stock,category,image_url,available,deleted_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [p.id, p.name, p.description, p.price, p.stock, p.category, p.imageUrl, p.available, p.deletedAt]
      );
    }
    await c.query("SELECT setval(pg_get_serial_sequence('products','id'), (SELECT MAX(id) FROM products))");
    for (const pr of promos) {
      await c.query(
        `INSERT INTO promos (id,title,description,discount_pct,image_url,valid_from,valid_to) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [pr.id, pr.title, pr.description, pr.discountPct, pr.imageUrl, pr.validFrom, pr.validTo]
      );
      for (const productId of pr.productIds) {
        await c.query("INSERT INTO promo_products (promo_id, product_id) VALUES ($1,$2)", [pr.id, productId]);
      }
    }
  });
  console.log("Datos de prueba cargados");
}
