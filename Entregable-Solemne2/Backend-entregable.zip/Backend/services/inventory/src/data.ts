// Datos de prueba (seed). Solo se cargan si la tabla products está vacía.
export interface Product {
  id: number;
  name: string;
  description: string;
  price: number; // CLP
  stock: number; // dato interno
  category: "bowls" | "wraps" | "ensaladas";
  imageUrl: string | null;
  available: boolean;
  deletedAt: string | null; // baja lógica
}

export const products: Product[] = [
  { id: 1, name: "Bowl Mediterráneo", description: "Quinoa, pollo grillado, palta y hummus.", price: 6990, stock: 25, category: "bowls", imageUrl: "img/bowl-mediterraneo.jpg", available: true, deletedAt: null },
  { id: 2, name: "Bowl Poke", description: "Arroz, salmón, edamame y pepino.", price: 7490, stock: 20, category: "bowls", imageUrl: "img/bowl-poke.jpg", available: true, deletedAt: null },
  { id: 3, name: "Wrap de Pollo", description: "Tortilla integral, pollo y verduras.", price: 4990, stock: 30, category: "wraps", imageUrl: "img/wrap-pollo.jpg", available: true, deletedAt: null },
  { id: 4, name: "Wrap Vegetariano", description: "Falafel, hummus y vegetales frescos.", price: 4790, stock: 30, category: "wraps", imageUrl: "img/wrap-vegetariano.jpg", available: true, deletedAt: null },
  { id: 5, name: "Ensalada César", description: "Lechuga, pollo, crutones y parmesano.", price: 5490, stock: 25, category: "ensaladas", imageUrl: "img/ensalada-cesar.jpg", available: true, deletedAt: null },
  { id: 6, name: "Ensalada Verde", description: "Espinaca, palta, nueces y semillas.", price: 5290, stock: 25, category: "ensaladas", imageUrl: "img/ensalada-verde.jpg", available: true, deletedAt: null },
  // Datos de prueba para validar reglas (no están en el frontend):
  { id: 7, name: "Bowl de Temporada", description: "Prueba: producto no disponible.", price: 6490, stock: 0, category: "bowls", imageUrl: null, available: false, deletedAt: null },
  { id: 8, name: "Wrap Descontinuado", description: "Prueba: producto con baja lógica.", price: 3990, stock: 5, category: "wraps", imageUrl: null, available: true, deletedAt: "2026-10-01T00:00:00Z" },
];

export interface Promo {
  id: string;
  title: string;
  description: string;
  discountPct: number;
  imageUrl: string | null;
  validFrom: string;
  validTo: string;
  productIds: number[];
}

export const promos: Promo[] = [
  { id: "promo-1", title: "Martes de Wraps", description: "15% de descuento en todos los wraps", discountPct: 15, imageUrl: "img/promo-wraps.jpg", validFrom: "2026-11-01T00:00:00Z", validTo: "2026-11-30T23:59:59Z", productIds: [3, 4] },
  { id: "promo-2", title: "Semana Bowl", description: "10% de descuento en bowls", discountPct: 10, imageUrl: "img/promo-bowls.jpg", validFrom: "2026-11-01T00:00:00Z", validTo: "2026-12-31T23:59:59Z", productIds: [1, 2] },
  { id: "promo-3", title: "Promo vencida", description: "Ya terminó", discountPct: 10, imageUrl: null, validFrom: "2026-09-01T00:00:00Z", validTo: "2026-09-30T23:59:59Z", productIds: [5, 6] },
];
