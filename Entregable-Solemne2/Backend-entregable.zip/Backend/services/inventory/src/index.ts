import "@shared/env";
import { env } from "@shared/env";
import { createApp, finish } from "@shared/http";
import { initDb } from "./db";
import { adminRouter } from "./routes/admin";
import { internalRouter } from "./routes/internal";
import { publicRouter } from "./routes/public";

const app = createApp("inventory");

app.use("/", publicRouter); // S01, S02, S03 (anónimo)
app.use("/admin", adminRouter); // S34 a S38 (ADMIN)
app.use("/internal", internalRouter); // privado: solo servicios
finish(app);

const PORT = Number(env("INVENTORY_PORT", "3002"));
initDb()
  .then(() => app.listen(PORT, () => console.log(`Inventory escuchando en http://localhost:${PORT}`)))
  .catch((e) => {
    console.error("No se pudo iniciar Inventory:", e.message);
    process.exit(1);
  });
