import { Router } from "express";
import { z } from "zod";
import { serviceAuth } from "@shared/auth";
import { HttpError, asyncHandler, conflict } from "@shared/errors";
import { tx } from "@shared/db";
import { validate } from "@shared/validate";
import { pool } from "../db";

// Rutas privadas para Orders y GraphQL (token de servicio)
export const internalRouter = Router();
internalRouter.use(serviceAuth);

const reserveSchema = z
  .object({
    orderId: z.string().min(3).max(60),
    items: z.array(z.object({ productId: z.number().int().positive(), quantity: z.number().int().min(1).max(99) }).strict()).min(1).max(50),
  })
  .strict();

// Orders (S21): lee precios REALES, aplica la promo vigente y aparta el stock en una sola transacción
internalRouter.post(
  "/stock/reserve",
  validate(reserveSchema),
  asyncHandler(async (req, res) => {
    const { orderId, items } = req.body as z.infer<typeof reserveSchema>;
    const result = await tx(pool, async (c) => {
      const exists = await c.query("SELECT 1 FROM stock_reservations WHERE order_id = $1 LIMIT 1", [orderId]);
      if (exists.rowCount) throw conflict("ALREADY_RESERVED", "El pedido ya tiene stock reservado");

      const ids = items.map((i) => i.productId);
      // FOR UPDATE: dos pedidos simultáneos no pueden llevarse la misma última unidad
      const { rows } = await c.query(
        "SELECT id, name, price, stock, available, deleted_at FROM products WHERE id = ANY($1::int[]) ORDER BY id FOR UPDATE",
        [ids]
      );
      const byId = new Map<number, any>(rows.map((r) => [r.id, r]));

      const promo = await c.query(
        `SELECT pp.product_id, MAX(p.discount_pct)::int AS pct
         FROM promos p JOIN promo_products pp ON pp.promo_id = p.id
         WHERE p.valid_from <= now() AND now() <= p.valid_to AND pp.product_id = ANY($1::int[])
         GROUP BY pp.product_id`,
        [ids]
      );
      const pct = new Map<number, number>(promo.rows.map((r) => [r.product_id, r.pct]));

      const lines = [];
      for (const it of items) {
        const p = byId.get(it.productId);
        if (!p || p.deleted_at || !p.available)
          throw new HttpError(422, "PRODUCT_UNAVAILABLE", `El producto ${it.productId} no está disponible`, { productId: it.productId });
        if (p.stock < it.quantity)
          throw new HttpError(422, "INSUFFICIENT_STOCK", `Stock insuficiente para el producto ${it.productId}`, { productId: it.productId });

        const discountPct = pct.get(it.productId) ?? 0;
        lines.push({
          productId: it.productId,
          name: p.name,
          basePrice: p.price,
          discountPct,
          unitPrice: Math.round((p.price * (100 - discountPct)) / 100),
          quantity: it.quantity,
        });
        await c.query("UPDATE products SET stock = stock - $2 WHERE id = $1", [it.productId, it.quantity]);
        await c.query("INSERT INTO stock_reservations (order_id, product_id, quantity) VALUES ($1,$2,$3)", [orderId, it.productId, it.quantity]);
      }
      return lines;
    });
    res.json({ items: result });
  })
);

// Orders (S24): devuelve el stock apartado. Idempotente: llamarlo dos veces no suma dos veces.
internalRouter.post(
  "/stock/release",
  validate(z.object({ orderId: z.string().min(3).max(60) }).strict()),
  asyncHandler(async (req, res) => {
    const released = await tx(pool, async (c) => {
      const { rows } = await c.query("SELECT id, product_id, quantity FROM stock_reservations WHERE order_id = $1 AND released_at IS NULL FOR UPDATE", [req.body.orderId]);
      for (const r of rows) {
        await c.query("UPDATE products SET stock = stock + $2 WHERE id = $1", [r.product_id, r.quantity]);
        await c.query("UPDATE stock_reservations SET released_at = now() WHERE id = $1", [r.id]);
      }
      return rows.length;
    });
    res.json({ released });
  })
);

// GraphQL (S39): datos vigentes de varios productos en UNA llamada (evita N+1)
internalRouter.get(
  "/products",
  asyncHandler(async (req, res) => {
    const ids = String(req.query.ids ?? "").split(",").map(Number).filter((n) => Number.isInteger(n) && n > 0).slice(0, 50);
    if (ids.length === 0) return res.json([]);
    const { rows } = await pool.query(
      `SELECT id, name, price, category, image_url AS "imageUrl", available FROM products WHERE id = ANY($1::int[]) AND deleted_at IS NULL`,
      [ids]
    );
    res.json(rows);
  })
);
