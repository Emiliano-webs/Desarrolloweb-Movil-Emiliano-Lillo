import { Router } from "express";
import { z } from "zod";
import { authenticate, requireRole } from "@shared/auth";
import { asyncHandler, conflict, notFound } from "@shared/errors";
import { pageQuery, validate } from "@shared/validate";
import { pool } from "../db";

// Mantenedor de productos: solo ADMIN. Ocultar botones en el frontend no reemplaza este control.
export const adminRouter = Router();
adminRouter.use(authenticate, requireRole("ADMIN"));

const ADMIN_COLS = `id, name, description, price, stock, category, image_url AS "imageUrl", available, deleted_at AS "deletedAt"`;
const idParam = validate(z.object({ id: z.coerce.number().int().positive() }), "params");

const name = z.string().trim().min(2).max(100);
const description = z.string().trim().min(1).max(500);
const price = z.number().int().positive().max(10_000_000);
const stock = z.number().int().min(0).max(100_000);
const category = z.enum(["bowls", "wraps", "ensaladas"]);
const imageUrl = z.string().trim().max(300).nullable();

// S34
adminRouter.get(
  "/products",
  validate(z.object({ includeDeleted: z.enum(["true", "false"]).default("false"), ...pageQuery }).strict(), "query"),
  asyncHandler(async (req, res) => {
    const { includeDeleted, page, size } = req.query as any;
    const where = includeDeleted === "true" ? "TRUE" : "deleted_at IS NULL";
    const total = await pool.query(`SELECT COUNT(*)::int AS n FROM products WHERE ${where}`);
    const { rows } = await pool.query(`SELECT ${ADMIN_COLS} FROM products WHERE ${where} ORDER BY id LIMIT $1 OFFSET $2`, [size, (page - 1) * size]);
    res.json({ items: rows, page, size, total: total.rows[0].n });
  })
);

// S35 (id, available y deletedAt los fija el servidor)
adminRouter.post(
  "/products",
  validate(z.object({ name, description, price, stock, category, imageUrl: imageUrl.optional() }).strict()),
  asyncHandler(async (req, res) => {
    const b = req.body;
    const { rows } = await pool.query(
      `INSERT INTO products (name,description,price,stock,category,image_url) VALUES ($1,$2,$3,$4,$5,$6) RETURNING ${ADMIN_COLS}`,
      [b.name, b.description, b.price, b.stock, b.category, b.imageUrl ?? null]
    );
    res.status(201).json(rows[0]);
  })
);

// S36 (un cambio de precio no altera pedidos ya creados: cada pedido guarda su precio)
const COLUMN: Record<string, string> = { name: "name", description: "description", price: "price", stock: "stock", category: "category", imageUrl: "image_url" };
adminRouter.put(
  "/products/:id",
  idParam,
  validate(
    z.object({ name: name.optional(), description: description.optional(), price: price.optional(), stock: stock.optional(), category: category.optional(), imageUrl: imageUrl.optional() })
      .strict()
      .refine((v) => Object.keys(v).length > 0, "Debes enviar al menos un campo")
  ),
  asyncHandler(async (req, res) => {
    const sets: string[] = [];
    const params: unknown[] = [req.params.id];
    for (const [key, value] of Object.entries(req.body)) {
      params.push(value);
      sets.push(`${COLUMN[key]} = $${params.length}`); // los nombres de columna salen de una lista blanca
    }
    const { rows } = await pool.query(`UPDATE products SET ${sets.join(", ")} WHERE id = $1 AND deleted_at IS NULL RETURNING ${ADMIN_COLS}`, params);
    if (!rows[0]) throw notFound("Producto no encontrado");
    res.json(rows[0]);
  })
);

// S37
adminRouter.put(
  "/products/:id/availability",
  idParam,
  validate(z.object({ available: z.boolean() }).strict()),
  asyncHandler(async (req, res) => {
    const cur = await pool.query("SELECT deleted_at FROM products WHERE id = $1", [req.params.id]);
    if (!cur.rows[0]) throw notFound("Producto no encontrado");
    if (cur.rows[0].deleted_at) throw conflict("INVALID_STATE", "El producto está dado de baja");
    const { rows } = await pool.query("UPDATE products SET available = $2 WHERE id = $1 RETURNING id, available", [req.params.id, req.body.available]);
    res.json(rows[0]);
  })
);

// S38 baja lógica: no se borra la fila, los pedidos históricos conservan la referencia
adminRouter.delete(
  "/products/:id",
  idParam,
  asyncHandler(async (req, res) => {
    const r = await pool.query("UPDATE products SET deleted_at = COALESCE(deleted_at, now()) WHERE id = $1", [req.params.id]);
    if (!r.rowCount) throw notFound("Producto no encontrado");
    res.status(204).end(); // idempotente
  })
);
