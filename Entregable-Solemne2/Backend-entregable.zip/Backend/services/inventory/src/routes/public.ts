import { Router } from "express";
import { z } from "zod";
import { asyncHandler, notFound } from "@shared/errors";
import { limiter } from "@shared/http";
import { pageQuery, validate } from "@shared/validate";
import { pool } from "../db";

export const publicRouter = Router();
const catalogLimit = limiter(60_000, 100); // catálogo anónimo: 100 por minuto por IP (solo estas rutas)

// Solo columnas públicas: el stock nunca sale de la base de datos hacia la API
const PUBLIC_COLS = `id, name, description, price, category, image_url AS "imageUrl", available`;

// S01
publicRouter.get(
  "/products",
  catalogLimit,
  validate(z.object({ category: z.enum(["bowls", "wraps", "ensaladas"]).optional(), ...pageQuery }).strict(), "query"),
  asyncHandler(async (req, res) => {
    const { category, page, size } = req.query as any;
    const params: unknown[] = [];
    let where = "deleted_at IS NULL AND available = true";
    if (category) {
      params.push(category);
      where += ` AND category = $${params.length}`;
    }
    const total = await pool.query(`SELECT COUNT(*)::int AS n FROM products WHERE ${where}`, params);
    params.push(size, (page - 1) * size);
    const { rows } = await pool.query(
      `SELECT ${PUBLIC_COLS} FROM products WHERE ${where} ORDER BY id LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    res.json({ items: rows, page, size, total: total.rows[0].n });
  })
);

// S02
publicRouter.get(
  "/products/:id",
  catalogLimit,
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) throw notFound("Producto no encontrado");
    const { rows } = await pool.query(`SELECT ${PUBLIC_COLS} FROM products WHERE id = $1 AND deleted_at IS NULL`, [id]);
    if (!rows[0]) throw notFound("Producto no encontrado"); // baja lógica = inexistente
    res.json(rows[0]);
  })
);

// S03 (vigencia con la hora del servidor de base de datos)
publicRouter.get(
  "/promos",
  catalogLimit,
  asyncHandler(async (_req, res) => {
    const { rows } = await pool.query(`
      SELECT p.id, p.title, p.description,
             p.discount_pct AS "discountPct", p.image_url AS "imageUrl",
             p.valid_from AS "validFrom", p.valid_to AS "validTo",
             COALESCE(array_agg(pp.product_id ORDER BY pp.product_id) FILTER (WHERE pp.product_id IS NOT NULL), '{}') AS "productIds"
      FROM promos p LEFT JOIN promo_products pp ON pp.promo_id = p.id
      WHERE p.valid_from <= now() AND now() <= p.valid_to
      GROUP BY p.id ORDER BY p.id`);
    res.json(rows);
  })
);
