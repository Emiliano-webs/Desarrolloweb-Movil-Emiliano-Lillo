import type { PoolClient } from "pg";
import { pool } from "./db";

export const ORDER_STATUSES = ["PENDING_PAYMENT", "PAID", "SOLD", "IN_PREPARATION", "READY", "OUT_FOR_DELIVERY", "DELIVERED", "CANCELLED"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

// Máquina de estados del despacho: sin retrocesos ni saltos
export const DISPATCH_TRANSITIONS: Record<string, string> = {
  SOLD: "IN_PREPARATION",
  IN_PREPARATION: "READY",
  READY: "OUT_FOR_DELIVERY",
  OUT_FOR_DELIVERY: "DELIVERED",
};
export const DISPATCH_STATUSES = ["SOLD", "IN_PREPARATION", "READY", "OUT_FOR_DELIVERY"];
export const CANCELLABLE = ["PENDING_PAYMENT", "PAID", "SOLD"];

export async function nextOrderId(): Promise<string> {
  const { rows } = await pool.query("SELECT nextval('order_seq') AS n");
  const d = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  return `o-${d}-${String(rows[0].n).padStart(6, "0")}`;
}

export async function addHistory(c: PoolClient, orderId: string, from: string | null, to: string, by: string) {
  await c.query("INSERT INTO order_status_history (order_id, from_status, to_status, changed_by) VALUES ($1,$2,$3,$4)", [orderId, from, to, by]);
}

export const itemDto = (r: any) => ({
  productId: r.product_id,
  name: r.name_snapshot,
  quantity: r.quantity,
  unitPrice: r.unit_price,
  lineTotal: r.line_total,
});

// Pedido completo (con ítems) para el cliente dueño o para consultas internas
export async function loadOrder(id: string, customerId?: string) {
  const params: unknown[] = [id];
  let where = "id = $1";
  if (customerId) {
    params.push(customerId);
    where += " AND customer_id = $2"; // control de propiedad dentro de la propia consulta
  }
  const o = await pool.query(`SELECT * FROM orders WHERE ${where}`, params);
  if (!o.rows[0]) return null;
  const items = await pool.query("SELECT * FROM order_items WHERE order_id = $1 ORDER BY id", [id]);
  const r = o.rows[0];
  return {
    id: r.id,
    customerId: r.customer_id,
    status: r.status,
    subtotal: r.subtotal,
    deliveryFee: r.delivery_fee,
    total: r.total,
    currency: r.currency,
    shipping: r.shipping,
    notes: r.notes,
    cancelReason: r.cancel_reason,
    createdAt: r.created_at,
    items: items.rows.map(itemDto),
  };
}
