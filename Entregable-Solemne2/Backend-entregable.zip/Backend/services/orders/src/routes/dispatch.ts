import { Router } from "express";
import { z } from "zod";
import { authenticate, requireRole } from "@shared/auth";
import { asyncHandler, conflict, notFound } from "@shared/errors";
import { tx } from "@shared/db";
import { validate } from "@shared/validate";
import { DISPATCH_STATUSES, DISPATCH_TRANSITIONS, addHistory } from "../common";
import { pool } from "../db";

export const dispatchRouter = Router();
dispatchRouter.use(authenticate, requireRole("DESPACHO"));
const idParam = validate(z.object({ id: z.string().regex(/^o-\d{8}-\d{6}$/) }), "params");

// ---------- S30 Cola de despacho (orden de llegada) ----------
dispatchRouter.get(
  "/orders",
  validate(z.object({ status: z.enum(["SOLD", "IN_PREPARATION", "READY", "OUT_FOR_DELIVERY"]).optional() }).strict(), "query"),
  asyncHandler(async (req, res) => {
    const status = (req.query as any).status as string | undefined;
    const { rows } = await pool.query(
      `SELECT o.id AS "orderId", o.status, o.created_at AS "createdAt",
              (SELECT COALESCE(SUM(quantity),0)::int FROM order_items i WHERE i.order_id = o.id) AS "itemsCount"
       FROM orders o WHERE o.status = ANY($1::text[]) ORDER BY o.created_at ASC`,
      [status ? [status] : DISPATCH_STATUSES]
    );
    res.json(rows);
  })
);

// ---------- S31 Vista imprimible: solo lo necesario para preparar y entregar (sin RUN ni montos) ----------
dispatchRouter.get(
  "/orders/:id/print",
  idParam,
  asyncHandler(async (req, res) => {
    const o = await pool.query("SELECT id, status, shipping, notes, created_at FROM orders WHERE id = $1", [req.params.id]);
    if (!o.rows[0]) throw notFound("Pedido no encontrado");
    if (!DISPATCH_STATUSES.includes(o.rows[0].status)) throw conflict("INVALID_STATE", "El pedido no está en la cola de despacho");
    const items = await pool.query("SELECT name_snapshot AS name, quantity FROM order_items WHERE order_id = $1 ORDER BY id", [req.params.id]);
    await pool.query("INSERT INTO print_log (order_id, printed_by) VALUES ($1,$2)", [req.params.id, req.user!.sub]);
    const { alias: _a, ...shipping } = o.rows[0].shipping;
    res.json({ orderId: o.rows[0].id, createdAt: o.rows[0].created_at, items: items.rows, notes: o.rows[0].notes, shipping });
  })
);

// ---------- S32 Cambiar estado (máquina de estados en el servidor) ----------
dispatchRouter.put(
  "/orders/:id/status",
  idParam,
  validate(z.object({ status: z.enum(["IN_PREPARATION", "READY", "OUT_FOR_DELIVERY", "DELIVERED"]) }).strict()),
  asyncHandler(async (req, res) => {
    const out = await tx(pool, async (c) => {
      const cur = await c.query("SELECT status FROM orders WHERE id = $1 FOR UPDATE", [req.params.id]);
      if (!cur.rows[0]) throw notFound("Pedido no encontrado");
      const from = cur.rows[0].status as string;
      if (DISPATCH_TRANSITIONS[from] !== req.body.status)
        throw conflict("INVALID_STATE", `Transición no permitida: ${from} -> ${req.body.status}`, { from, to: req.body.status });
      const upd = await c.query("UPDATE orders SET status = $2, updated_at = now() WHERE id = $1 RETURNING updated_at", [req.params.id, req.body.status]);
      await addHistory(c, req.params.id, from, req.body.status, req.user!.sub);
      return upd.rows[0];
    });
    res.json({ orderId: req.params.id, status: req.body.status, updatedAt: out.updated_at });
  })
);
