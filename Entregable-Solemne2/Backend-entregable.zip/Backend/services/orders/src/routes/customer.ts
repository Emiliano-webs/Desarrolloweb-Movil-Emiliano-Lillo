import { Router } from "express";
import { z } from "zod";
import { authenticate, requireRole } from "@shared/auth";
import { HttpError, asyncHandler, conflict, notFound } from "@shared/errors";
import { tx } from "@shared/db";
import { env } from "@shared/env";
import { callService } from "@shared/internal";
import { pageQuery, validate } from "@shared/validate";
import { CANCELLABLE, ORDER_STATUSES, addHistory, loadOrder, nextOrderId } from "../common";
import { pool } from "../db";

export const customerRouter = Router();
const CLIENTS_URL = () => env("CLIENTS_URL");
const INVENTORY_URL = () => env("INVENTORY_URL");
const PAYMENTS_URL = () => env("PAYMENTS_URL");
const orderIdParam = validate(z.object({ id: z.string().regex(/^o-\d{8}-\d{6}$/) }), "params");

// ---------- S21 Crear pedido: el servidor calcula precios, subtotal, despacho y total ----------
const createSchema = z
  .object({
    addressId: z.string().uuid(),
    items: z.array(z.object({ productId: z.number().int().positive(), quantity: z.number().int().min(1).max(99) }).strict()).min(1).max(50),
    notes: z.string().trim().max(200).optional(),
  })
  .strict(); // total, unitPrice, status, customerId => 400

customerRouter.post(
  "/orders",
  authenticate,
  requireRole("CLIENTE"),
  validate(createSchema),
  asyncHandler(async (req, res) => {
    const customerId = req.user!.sub; // del JWT, nunca del body
    const { addressId, items, notes } = req.body as z.infer<typeof createSchema>;

    const merged = new Map<number, number>();
    for (const it of items) merged.set(it.productId, (merged.get(it.productId) ?? 0) + it.quantity);
    for (const q of merged.values()) if (q > 99) throw new HttpError(400, "VALIDATION_ERROR", "La cantidad por producto no puede superar 99");

    // 1) la dirección debe ser del cliente autenticado (si no, 404)
    const addr = await callService("clients", CLIENTS_URL(), `/internal/clients/${customerId}/addresses/${addressId}`, { cid: req.cid });
    if (addr.status === 404) throw notFound("Dirección no encontrada");
    if (addr.status !== 200) throw new HttpError(502, "DEPENDENCY_ERROR", "No se pudo validar la dirección");

    // 2) Inventory entrega precios reales y aparta el stock
    const orderId = await nextOrderId();
    const stock = await callService("inventory", INVENTORY_URL(), "/internal/stock/reserve", {
      method: "POST",
      cid: req.cid,
      body: { orderId, items: [...merged].map(([productId, quantity]) => ({ productId, quantity })) },
    });
    if (stock.status === 422)
      throw new HttpError(422, stock.data?.error ?? "UNPROCESSABLE", stock.data?.message ?? "No se pudo reservar el stock", { productId: stock.data?.productId });
    if (stock.status !== 200) throw new HttpError(502, "DEPENDENCY_ERROR", "No se pudo reservar el stock");

    // 3) total = Σ(precio real × cantidad) + despacho, calculado aquí
    const lines = stock.data.items as { productId: number; name: string; unitPrice: number; quantity: number }[];
    const subtotal = lines.reduce((s, l) => s + l.unitPrice * l.quantity, 0);
    const deliveryFee = Number(env("DELIVERY_FEE", "1500"));
    const total = subtotal + deliveryFee;

    try {
      await tx(pool, async (c) => {
        await c.query(
          `INSERT INTO orders (id, customer_id, status, subtotal, delivery_fee, total, shipping, notes)
           VALUES ($1,$2,'PENDING_PAYMENT',$3,$4,$5,$6,$7)`,
          [orderId, customerId, subtotal, deliveryFee, total, JSON.stringify(addr.data), notes ?? null]
        );
        for (const l of lines) {
          await c.query(
            "INSERT INTO order_items (order_id, product_id, name_snapshot, unit_price, quantity, line_total) VALUES ($1,$2,$3,$4,$5,$6)",
            [orderId, l.productId, l.name, l.unitPrice, l.quantity, l.unitPrice * l.quantity]
          );
        }
        await addHistory(c, orderId, null, "PENDING_PAYMENT", customerId);
      });
    } catch (e) {
      // Compensación: si no se pudo guardar el pedido, se devuelve el stock apartado
      await callService("inventory", INVENTORY_URL(), "/internal/stock/release", { method: "POST", body: { orderId }, cid: req.cid }).catch(() => {});
      throw e;
    }
    res.status(201).json(await loadOrder(orderId, customerId).then((o) => publicOrder(o)));
  })
);

// customerId no es necesario para el dueño: se omite de la respuesta al cliente
const publicOrder = (o: any) => {
  if (!o) return o;
  const { customerId: _omit, ...rest } = o;
  return rest;
};

// ---------- S22 Listar pedidos propios ----------
customerRouter.get(
  "/orders",
  authenticate,
  requireRole("CLIENTE"),
  validate(z.object({ status: z.enum(ORDER_STATUSES).optional(), ...pageQuery }).strict(), "query"), // un customerId en la query => 400
  asyncHandler(async (req, res) => {
    const { status, page, size } = req.query as any;
    const params: unknown[] = [req.user!.sub];
    let where = "customer_id = $1";
    if (status) {
      params.push(status);
      where += ` AND status = $${params.length}`;
    }
    const total = await pool.query(`SELECT COUNT(*)::int AS n FROM orders WHERE ${where}`, params);
    params.push(size, (page - 1) * size);
    const { rows } = await pool.query(
      `SELECT id AS "orderId", status, total, created_at AS "createdAt" FROM orders WHERE ${where}
       ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    res.json({ items: rows, page, size, total: total.rows[0].n });
  })
);

// ---------- S23 Detalle de un pedido propio (anti-IDOR: uno ajeno responde 404) ----------
customerRouter.get(
  "/orders/:id",
  authenticate,
  requireRole("CLIENTE"),
  orderIdParam,
  asyncHandler(async (req, res) => {
    const order = await loadOrder(req.params.id, req.user!.sub);
    if (!order) throw notFound("Pedido no encontrado");
    res.json(publicOrder(order));
  })
);

// ---------- S24 Anular pedido (no se borra: queda CANCELLED con motivo y autor) ----------
customerRouter.post(
  "/orders/:id/cancellation",
  authenticate,
  requireRole("CLIENTE", "ADMIN"),
  orderIdParam,
  validate(z.object({ reason: z.string().trim().min(5).max(200) }).strict()),
  asyncHandler(async (req, res) => {
    const id = req.params.id;
    const user = req.user!;
    // El cliente solo anula los suyos (404 si es ajeno); el ADMIN cualquiera
    const params: unknown[] = [id];
    let where = "id = $1";
    if (user.role === "CLIENTE") {
      params.push(user.sub);
      where += " AND customer_id = $2";
    }
    const cur = await pool.query(`SELECT status FROM orders WHERE ${where}`, params);
    if (!cur.rows[0]) throw notFound("Pedido no encontrado");
    const from = cur.rows[0].status as string;
    if (!CANCELLABLE.includes(from)) throw conflict("INVALID_STATE", `Un pedido en estado ${from} ya no se puede anular`, { status: from });

    // Pasos idempotentes: si alguno falla se puede reintentar sin duplicar efectos
    const rel = await callService("inventory", INVENTORY_URL(), "/internal/stock/release", { method: "POST", body: { orderId: id }, cid: req.cid });
    if (rel.status !== 200) throw new HttpError(502, "DEPENDENCY_ERROR", "No se pudo devolver el stock");
    if (from !== "PENDING_PAYMENT") {
      const ref = await callService("payments", PAYMENTS_URL(), `/internal/payments/by-order/${id}/refund`, { method: "POST", cid: req.cid });
      if (ref.status !== 200) throw new HttpError(502, "DEPENDENCY_ERROR", "No se pudo iniciar el reembolso");
    }

    const out = await tx(pool, async (c) => {
      const upd = await c.query(
        `UPDATE orders SET status = 'CANCELLED', cancel_reason = $2, cancelled_by = $3, cancelled_at = now(), updated_at = now()
         WHERE id = $1 AND status = $4 RETURNING cancelled_at`,
        [id, req.body.reason, user.sub, from]
      );
      if (!upd.rowCount) throw conflict("INVALID_STATE", "El pedido cambió de estado, intenta nuevamente");
      await addHistory(c, id, from, "CANCELLED", user.sub);
      return upd.rows[0];
    });
    res.json({ orderId: id, status: "CANCELLED", cancelledAt: out.cancelled_at, cancelledBy: user.role });
  })
);
