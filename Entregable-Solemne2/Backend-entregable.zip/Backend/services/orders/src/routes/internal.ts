import { Router } from "express";
import { z } from "zod";
import { serviceAuth } from "@shared/auth";
import { HttpError, asyncHandler, conflict, notFound } from "@shared/errors";
import { tx } from "@shared/db";
import { validate } from "@shared/validate";
import { addHistory, loadOrder } from "../common";
import { pool } from "../db";

// Rutas privadas para Payments y GraphQL (token de servicio)
export const internalRouter = Router();
internalRouter.use(serviceAuth);
const orderId = z.string().regex(/^o-\d{8}-\d{6}$/);

// Payments (S25) y GraphQL (S39): pedido completo, incluido el dueño para que verifiquen propiedad
internalRouter.get(
  "/orders/:id",
  validate(z.object({ id: orderId }), "params"),
  asyncHandler(async (req, res) => {
    const order = await loadOrder(req.params.id);
    if (!order) throw notFound("Pedido no encontrado");
    res.json(order);
  })
);

// Payments (S26): único camino hacia PAID. Idempotente: marcar dos veces no falla ni duplica.
internalRouter.post(
  "/orders/:id/mark-paid",
  validate(z.object({ id: orderId }), "params"),
  asyncHandler(async (req, res) => {
    const out = await tx(pool, async (c) => {
      const cur = await c.query("SELECT status FROM orders WHERE id = $1 FOR UPDATE", [req.params.id]);
      if (!cur.rows[0]) throw notFound("Pedido no encontrado");
      const from = cur.rows[0].status as string;
      if (from === "PAID") return { status: "PAID", changed: false };
      if (from !== "PENDING_PAYMENT") throw conflict("INVALID_STATE", `Un pedido en estado ${from} no puede pasar a PAID`, { status: from });
      await c.query("UPDATE orders SET status = 'PAID', updated_at = now() WHERE id = $1", [req.params.id]);
      await addHistory(c, req.params.id, from, "PAID", "system");
      return { status: "PAID", changed: true };
    });
    res.json(out);
  })
);

// GraphQL (S33): ventas agregadas por día (no incluye datos personales)
internalRouter.get(
  "/sales/aggregate",
  validate(z.object({ desde: z.coerce.date(), hasta: z.coerce.date() }).strict(), "query"),
  asyncHandler(async (req, res) => {
    const { desde, hasta } = req.query as any as { desde: Date; hasta: Date };
    if (hasta < desde) throw new HttpError(400, "VALIDATION_ERROR", "hasta debe ser posterior a desde");
    const { rows } = await pool.query(
      `SELECT to_char(date_trunc('day', s.issued_at AT TIME ZONE 'America/Santiago'), 'YYYY-MM-DD') AS date,
              COUNT(*)::int AS sales, COALESCE(SUM(s.total),0)::int AS amount
       FROM sales s JOIN orders o ON o.id = s.order_id
       WHERE s.issued_at BETWEEN $1 AND $2 AND o.status <> 'CANCELLED'
       GROUP BY 1 ORDER BY 1`,
      [desde, hasta]
    );
    res.json({
      totalSales: rows.reduce((a, r) => a + r.sales, 0),
      totalAmount: rows.reduce((a, r) => a + r.amount, 0),
      byDay: rows,
    });
  })
);
