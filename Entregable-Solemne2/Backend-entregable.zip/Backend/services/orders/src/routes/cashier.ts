import { randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { authenticate, requireRole } from "@shared/auth";
import { HttpError, asyncHandler, conflict, notFound } from "@shared/errors";
import { tx } from "@shared/db";
import { env } from "@shared/env";
import { callService } from "@shared/internal";
import { pageQuery, validate } from "@shared/validate";
import { addHistory, itemDto } from "../common";
import { pool } from "../db";

export const cashierRouter = Router();

// Nombre (y RUT enmascarado) desde Clients. Si Clients no responde, se entrega sin nombre en vez de fallar todo.
async function summaries(ids: string[], cid: string): Promise<Map<string, { name: string; runMasked: string }>> {
  const map = new Map();
  if (ids.length === 0) return map;
  try {
    const r = await callService("clients", env("CLIENTS_URL"), `/internal/clients/summaries?ids=${ids.join(",")}`, { cid });
    if (r.status === 200) for (const s of r.data) map.set(s.id, s);
  } catch {
    /* degradación controlada */
  }
  return map;
}

// ---------- S27 Pedidos pagados pendientes de venta ----------
cashierRouter.get(
  "/cashier/orders",
  authenticate,
  requireRole("CAJERO"),
  validate(z.object({ ...pageQuery }).strict(), "query"),
  asyncHandler(async (req, res) => {
    const { page, size } = req.query as any;
    const where = "o.status = 'PAID' AND NOT EXISTS (SELECT 1 FROM sales s WHERE s.order_id = o.id)";
    const total = await pool.query(`SELECT COUNT(*)::int AS n FROM orders o WHERE ${where}`);
    const { rows } = await pool.query(
      `SELECT o.id AS "orderId", o.customer_id, o.total,
              (SELECT MAX(h.at) FROM order_status_history h WHERE h.order_id = o.id AND h.to_status = 'PAID') AS "paidAt"
       FROM orders o WHERE ${where} ORDER BY o.created_at LIMIT $1 OFFSET $2`,
      [size, (page - 1) * size]
    );
    const names = await summaries([...new Set(rows.map((r) => r.customer_id))], req.cid);
    res.json({
      items: rows.map((r) => ({ orderId: r.orderId, customerName: names.get(r.customer_id)?.name ?? null, total: r.total, paidAt: r.paidAt })),
      page,
      size,
      total: total.rows[0].n,
    });
  })
);

// ---------- S28 Realizar venta y emitir boleta (solo pedidos pagados) ----------
cashierRouter.post(
  "/sales",
  authenticate,
  requireRole("CAJERO"),
  validate(z.object({ orderId: z.string().regex(/^o-\d{8}-\d{6}$/) }).strict()), // el monto NO viene del cliente
  asyncHandler(async (req, res) => {
    const { orderId } = req.body;
    const sale = await tx(pool, async (c) => {
      const o = await c.query("SELECT status, total FROM orders WHERE id = $1 FOR UPDATE", [orderId]);
      if (!o.rows[0]) throw notFound("Pedido no encontrado");
      const dup = await c.query("SELECT 1 FROM sales WHERE order_id = $1", [orderId]);
      if (dup.rowCount) throw conflict("ALREADY_SOLD", "El pedido ya tiene una venta registrada");
      if (o.rows[0].status !== "PAID") throw new HttpError(422, "ORDER_NOT_PAID", "Solo se pueden vender pedidos pagados", { status: o.rows[0].status });

      const seq = await c.query("SELECT nextval('receipt_seq') AS n");
      const receiptNumber = `B-${String(seq.rows[0].n).padStart(6, "0")}`; // correlativo del servidor
      const id = randomUUID();
      const ins = await c.query(
        `INSERT INTO sales (id, order_id, receipt_number, total, cashier_id) VALUES ($1,$2,$3,$4,$5)
         RETURNING id AS "saleId", receipt_number AS "receiptNumber", order_id AS "orderId", total, issued_at AS "issuedAt"`,
        [id, orderId, receiptNumber, o.rows[0].total, req.user!.sub]
      );
      await c.query("UPDATE orders SET status = 'SOLD', updated_at = now() WHERE id = $1", [orderId]);
      await addHistory(c, orderId, "PAID", "SOLD", req.user!.sub);
      return ins.rows[0];
    });
    res.status(201).json(sale);
  })
);

// ---------- S29 Ver boleta (CAJERO, ADMIN o el cliente dueño) ----------
cashierRouter.get(
  "/sales/:id/receipt",
  authenticate,
  requireRole("CAJERO", "ADMIN", "CLIENTE"),
  validate(z.object({ id: z.string().uuid() }), "params"),
  asyncHandler(async (req, res) => {
    const { rows } = await pool.query(
      `SELECT s.id, s.receipt_number, s.total, s.issued_at, o.id AS order_id, o.customer_id, o.subtotal, o.delivery_fee
       FROM sales s JOIN orders o ON o.id = s.order_id WHERE s.id = $1`,
      [req.params.id]
    );
    const s = rows[0];
    if (!s || (req.user!.role === "CLIENTE" && s.customer_id !== req.user!.sub)) throw notFound("Boleta no encontrada");
    const items = await pool.query("SELECT * FROM order_items WHERE order_id = $1 ORDER BY id", [s.order_id]);
    const client = (await summaries([s.customer_id], req.cid)).get(s.customer_id);
    res.json({
      receiptNumber: s.receipt_number,
      orderId: s.order_id,
      issuedAt: s.issued_at,
      customer: client ? { name: client.name, runMasked: client.runMasked } : null,
      items: items.rows.map(itemDto),
      subtotal: s.subtotal,
      deliveryFee: s.delivery_fee,
      total: s.total,
    });
  })
);
