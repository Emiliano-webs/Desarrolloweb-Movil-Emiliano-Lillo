import { createPool, waitForDb } from "@shared/db";

export const pool = createPool("ORDERS");

const SCHEMA = `
CREATE SEQUENCE IF NOT EXISTS order_seq;
CREATE SEQUENCE IF NOT EXISTS receipt_seq;

CREATE TABLE IF NOT EXISTS orders (
  id            TEXT PRIMARY KEY,
  customer_id   UUID NOT NULL,
  status        TEXT NOT NULL CHECK (status IN
                 ('PENDING_PAYMENT','PAID','SOLD','IN_PREPARATION','READY','OUT_FOR_DELIVERY','DELIVERED','CANCELLED')),
  subtotal      INTEGER NOT NULL CHECK (subtotal >= 0),
  delivery_fee  INTEGER NOT NULL CHECK (delivery_fee >= 0),
  total         INTEGER NOT NULL CHECK (total >= 0),
  currency      TEXT NOT NULL DEFAULT 'CLP',
  shipping      JSONB NOT NULL,            -- copia de la dirección al momento de comprar
  notes         TEXT,
  cancel_reason TEXT,
  cancelled_by  UUID,
  cancelled_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status, created_at);

CREATE TABLE IF NOT EXISTS order_items (
  id            SERIAL PRIMARY KEY,
  order_id      TEXT NOT NULL REFERENCES orders(id),
  product_id    INTEGER NOT NULL,          -- referencia por ID: Inventory es el dueño del producto
  name_snapshot TEXT NOT NULL,
  unit_price    INTEGER NOT NULL CHECK (unit_price >= 0),
  quantity      INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 99),
  line_total    INTEGER NOT NULL CHECK (line_total >= 0)
);
CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id);

CREATE TABLE IF NOT EXISTS order_status_history (
  id          SERIAL PRIMARY KEY,
  order_id    TEXT NOT NULL REFERENCES orders(id),
  from_status TEXT,
  to_status   TEXT NOT NULL,
  changed_by  TEXT NOT NULL,               -- id de usuario o 'system'
  at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sales (
  id             UUID PRIMARY KEY,
  order_id       TEXT NOT NULL UNIQUE REFERENCES orders(id),   -- un pedido, una sola venta
  receipt_number TEXT NOT NULL UNIQUE,
  total          INTEGER NOT NULL,
  cashier_id     UUID NOT NULL,
  issued_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS print_log (
  id         SERIAL PRIMARY KEY,
  order_id   TEXT NOT NULL REFERENCES orders(id),
  printed_by UUID NOT NULL,
  at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
`;

export async function initDb() {
  await waitForDb(pool);
  await pool.query(SCHEMA);
}
