import "@shared/env";
import { env } from "@shared/env";
import { createApp, finish } from "@shared/http";
import { initDb } from "./db";
import { cashierRouter } from "./routes/cashier";
import { customerRouter } from "./routes/customer";
import { dispatchRouter } from "./routes/dispatch";
import { internalRouter } from "./routes/internal";

const app = createApp("orders");

app.use("/", customerRouter); // S21 a S24
app.use("/", cashierRouter); // S27 a S29
app.use("/dispatch", dispatchRouter); // S30 a S32
app.use("/internal", internalRouter); // privado: solo servicios
finish(app);

const PORT = Number(env("ORDERS_PORT", "3003"));
initDb()
  .then(() => app.listen(PORT, () => console.log(`Orders escuchando en http://localhost:${PORT}`)))
  .catch((e) => {
    console.error("No se pudo iniciar Orders:", e.message);
    process.exit(1);
  });
