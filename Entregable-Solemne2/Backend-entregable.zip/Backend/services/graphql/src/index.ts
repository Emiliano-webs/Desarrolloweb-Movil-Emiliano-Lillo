import "@shared/env";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { NoSchemaIntrospectionCustomRule } from "graphql";
import { createSchema, createYoga } from "graphql-yoga";
import { authenticate, requireRole, verifyAccessToken } from "@shared/auth";
import { HttpError, asyncHandler } from "@shared/errors";
import { env } from "@shared/env";
import { createApp, finish, limiter } from "@shared/http";
import { queryLimits } from "./limits";
import { fetchSales, makeProductLoader, resolvers, type Ctx } from "./resolvers";

const isProd = process.env.NODE_ENV === "production";

// Sin express.json: Yoga lee su propio cuerpo (con tope de tamaño más abajo)
const app = createApp("graphql", { json: false });

const yoga = createYoga<{ req: any }, Ctx>({
  schema: createSchema({ typeDefs: readFileSync(join(__dirname, "schema.graphql"), "utf8"), resolvers }),
  graphqlEndpoint: "/graphql",
  maskedErrors: true, // no se filtran detalles internos
  graphiql: !isProd,
  context: ({ request }) => {
    let user = null;
    const m = /^Bearer (.+)$/.exec(request.headers.get("authorization") ?? "");
    if (m) {
      try {
        user = verifyAccessToken(m[1]);
      } catch {
        /* token inválido: queda sin usuario y los resolvers responden UNAUTHENTICATED */
      }
    }
    const cid = request.headers.get("x-correlation-id") ?? crypto.randomUUID();
    return { user, cid, products: makeProductLoader(cid) };
  },
  validationRules: [queryLimits(5, 60), ...(isProd ? [NoSchemaIntrospectionCustomRule] : [])],
});

// POST /graphql (S39): 30 por minuto por IP; cuerpo máximo 100 KB (se revisa antes de entregar a Yoga)
app.use("/graphql", limiter(60_000, 30), (req, _res, next) => {
  if (Number(req.header("content-length") ?? 0) > 100_000) return next(new HttpError(413, "PAYLOAD_TOO_LARGE", "El cuerpo es demasiado grande"));
  next();
}, yoga);

// S33: GET /reports/sales?desde&hasta  (solo ADMIN)
app.get(
  "/reports/sales",
  authenticate,
  requireRole("ADMIN"),
  asyncHandler(async (req, res) => {
    const { desde, hasta } = req.query as Record<string, string>;
    if (!desde || !hasta) throw new HttpError(400, "VALIDATION_ERROR", "Debes enviar desde y hasta (ISO 8601)");
    try {
      res.json(await fetchSales(desde, hasta, req.cid));
    } catch (e: any) {
      if (e?.extensions?.code === "BAD_USER_INPUT") throw new HttpError(400, "VALIDATION_ERROR", e.message);
      throw new HttpError(502, "DEPENDENCY_ERROR", "No se pudo obtener el reporte");
    }
  })
);

finish(app);
const PORT = Number(env("GRAPHQL_PORT", "3005"));
app.listen(PORT, () => console.log(`GraphQL escuchando en http://localhost:${PORT}/graphql`));
