import DataLoader from "dataloader";
import { GraphQLError } from "graphql";
import type { AuthUser } from "@shared/types";
import { env } from "@shared/env";
import { callService } from "@shared/internal";

export interface Ctx {
  user: AuthUser | null; // del JWT ya verificado (RS256)
  cid: string;
  products: DataLoader<string, any>;
}

// Agrupa los productos de todas las líneas del pedido en UNA llamada a Inventory (evita N+1)
export const makeProductLoader = (cid: string) =>
  new DataLoader<string, any>(async (ids) => {
    try {
      const r = await callService("inventory", env("INVENTORY_URL"), `/internal/products?ids=${ids.join(",")}`, { cid });
      if (r.status !== 200) return ids.map(() => null);
      const byId = new Map<string, any>(r.data.map((p: any) => [String(p.id), p]));
      return ids.map((id) => byId.get(id) ?? null);
    } catch {
      return ids.map(() => null); // Inventory caído: error parcial, el pedido igual se entrega
    }
  });

const err = (message: string, code: string) => new GraphQLError(message, { extensions: { code } });
const requireUser = (ctx: Ctx) => ctx.user ?? (() => { throw err("No autenticado", "UNAUTHENTICATED"); })();

export const resolvers = {
  Query: {
    // S39: autorización por recurso. Cada pedido se valida contra el dueño; uno ajeno responde igual que "no existe".
    orderDetail: async (_: unknown, { id }: { id: string }, ctx: Ctx) => {
      const user = requireUser(ctx);
      if (user.role !== "CLIENTE" && user.role !== "ADMIN") throw err("Sin permisos", "FORBIDDEN");
      if (!/^o-\d{8}-\d{6}$/.test(id)) throw err("Pedido no encontrado", "NOT_FOUND");

      const r = await callService("orders", env("ORDERS_URL"), `/internal/orders/${id}`, { cid: ctx.cid });
      if (r.status === 404) throw err("Pedido no encontrado", "NOT_FOUND");
      if (r.status !== 200) throw err("Orders no disponible", "SERVICE_UNAVAILABLE");
      if (user.role === "CLIENTE" && r.data.customerId !== user.sub) throw err("Pedido no encontrado", "NOT_FOUND");
      return r.data; // customerId viaja en el objeto pero no existe en el schema: no se puede pedir
    },

    // S33: solo ADMIN
    salesReport: async (_: unknown, { desde, hasta }: { desde: string; hasta: string }, ctx: Ctx) => {
      const user = requireUser(ctx);
      if (user.role !== "ADMIN") throw err("Sin permisos", "FORBIDDEN");
      return fetchSales(desde, hasta, ctx.cid);
    },
  },

  OrderDetail: {
    // Subsistema Payments: solo se consulta si el cliente pidió el campo "payment"
    payment: async (order: any, _: unknown, ctx: Ctx) => {
      try {
        const r = await callService("payments", env("PAYMENTS_URL"), `/internal/payments/by-order/${order.id}`, { cid: ctx.cid });
        return r.status === 200 ? r.data : null;
      } catch {
        return null;
      }
    },
  },

  OrderLine: {
    // Subsistema Inventory: datos vigentes del producto
    product: async (line: any, _: unknown, ctx: Ctx) => {
      const p = await ctx.products.load(String(line.productId));
      if (!p) return null;
      return { id: p.id, currentPrice: p.price, available: p.available, category: p.category ?? null, imageUrl: p.imageUrl ?? null };
    },
  },
};

// Compartido entre GraphQL (salesReport) y REST (GET /reports/sales)
export async function fetchSales(desde: string, hasta: string, cid: string) {
  const d = new Date(desde);
  const h = new Date(hasta);
  const days = (h.getTime() - d.getTime()) / 86_400_000;
  if (isNaN(days) || days < 0 || days > 366) throw err("Rango inválido: desde <= hasta y máximo 366 días", "BAD_USER_INPUT");
  const r = await callService("orders", env("ORDERS_URL"), `/internal/sales/aggregate?desde=${encodeURIComponent(d.toISOString())}&hasta=${encodeURIComponent(h.toISOString())}`, { cid });
  if (r.status !== 200) throw err("Orders no disponible", "SERVICE_UNAVAILABLE");
  return { desde: d.toISOString(), hasta: h.toISOString(), ...r.data };
}
