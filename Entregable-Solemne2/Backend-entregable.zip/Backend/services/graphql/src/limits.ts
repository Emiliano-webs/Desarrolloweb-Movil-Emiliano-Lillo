import { GraphQLError, Kind, type ASTVisitor, type FragmentDefinitionNode, type SelectionSetNode, type ValidationContext } from "graphql";

type Frags = Record<string, FragmentDefinitionNode>;

function walk(sel: SelectionSetNode | undefined, frags: Frags, seen: Set<string>): { depth: number; fields: number } {
  let depth = 0;
  let fields = 0;
  if (!sel) return { depth, fields };
  for (const s of sel.selections) {
    if (s.kind === Kind.FIELD) {
      if (s.name.value.startsWith("__")) continue;
      const inner = walk(s.selectionSet, frags, seen);
      depth = Math.max(depth, 1 + inner.depth);
      fields += 1 + inner.fields;
    } else if (s.kind === Kind.INLINE_FRAGMENT) {
      const inner = walk(s.selectionSet, frags, seen);
      depth = Math.max(depth, inner.depth);
      fields += inner.fields;
    } else {
      const name = s.name.value;
      if (seen.has(name) || !frags[name]) continue;
      const inner = walk(frags[name].selectionSet, frags, new Set([...seen, name]));
      depth = Math.max(depth, inner.depth);
      fields += inner.fields;
    }
  }
  return { depth, fields };
}

// Regla de validación: limita la profundidad y la cantidad total de campos pedidos (costo de la consulta)
export const queryLimits = (maxDepth: number, maxFields: number) => (ctx: ValidationContext): ASTVisitor => {
  const frags: Frags = {};
  for (const d of ctx.getDocument().definitions) if (d.kind === Kind.FRAGMENT_DEFINITION) frags[d.name.value] = d;
  return {
    OperationDefinition(node) {
      const { depth, fields } = walk(node.selectionSet, frags, new Set());
      if (depth > maxDepth) ctx.reportError(new GraphQLError(`Consulta demasiado profunda (máximo ${maxDepth} niveles)`, { extensions: { code: "QUERY_TOO_DEEP" } }));
      if (fields > maxFields) ctx.reportError(new GraphQLError(`Consulta demasiado costosa (máximo ${maxFields} campos)`, { extensions: { code: "QUERY_TOO_COSTLY" } }));
    },
  };
};
