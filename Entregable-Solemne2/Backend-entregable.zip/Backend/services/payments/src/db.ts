import { createPool, waitForDb } from "@shared/db";

export const pool = createPool("PAYMENTS");

const SCHEMA = `
CREATE TABLE IF NOT EXISTS payments (
  id           TEXT PRIMARY KEY,
  order_id     TEXT NOT NULL,
  customer_id  UUID NOT NULL,
  amount       INTEGER NOT NULL CHECK (amount > 0),   -- copiado del pedido, nunca del cliente
  currency     TEXT NOT NULL DEFAULT 'CLP',
  status       TEXT NOT NULL CHECK (status IN ('PENDING','APPROVED','REJECTED','AMOUNT_MISMATCH','REFUNDED')),
  provider_ref TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Un solo pago activo (pendiente o aprobado) por pedido
CREATE UNIQUE INDEX IF NOT EXISTS one_active_payment ON payments(order_id) WHERE status IN ('PENDING','APPROVED');
CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(order_id, created_at DESC);

-- event_id es la llave primaria: una misma notificación nunca se procesa dos veces
CREATE TABLE IF NOT EXISTS webhook_events (
  event_id    TEXT PRIMARY KEY,
  payment_id  TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  result      TEXT NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
`;

export async function initDb() {
  await waitForDb(pool);
  await pool.query(SCHEMA);
}
