import "@shared/env";
import { env } from "@shared/env";
import { createApp, finish } from "@shared/http";
import { initDb } from "./db";
import { internalRouter } from "./routes/internal";
import { paymentsRouter } from "./routes/payments";
import { webhookRouter } from "./routes/webhook";

const app = createApp("payments");

app.use("/payments", paymentsRouter); // S25, S25b (CLIENTE)
app.use("/webhooks", webhookRouter); // S26 (firma HMAC, sin JWT)
app.use("/internal", internalRouter); // privado: solo servicios
finish(app);

const PORT = Number(env("PAYMENTS_PORT", "3004"));
initDb()
  .then(() => app.listen(PORT, () => console.log(`Payments escuchando en http://localhost:${PORT}`)))
  .catch((e) => {
    console.error("No se pudo iniciar Payments:", e.message);
    process.exit(1);
  });
