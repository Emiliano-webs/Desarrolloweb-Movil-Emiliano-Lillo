import { Router } from "express";
import { z } from "zod";
import { serviceAuth } from "@shared/auth";
import { asyncHandler, notFound } from "@shared/errors";
import { validate } from "@shared/validate";
import { pool } from "../db";

// Rutas privadas para Orders y GraphQL (token de servicio)
export const internalRouter = Router();
internalRouter.use(serviceAuth);
const params = validate(z.object({ orderId: z.string().regex(/^o-\d{8}-\d{6}$/) }), "params");

// GraphQL (S39): estado del pago de un pedido
internalRouter.get(
  "/payments/by-order/:orderId",
  params,
  asyncHandler(async (req, res) => {
    const { rows } = await pool.query("SELECT status, updated_at AS \"updatedAt\" FROM payments WHERE order_id = $1 ORDER BY created_at DESC LIMIT 1", [req.params.orderId]);
    if (!rows[0]) throw notFound("Pago no encontrado");
    res.json(rows[0]);
  })
);

// Orders (S24): reembolso simulado de un pago aprobado. Idempotente.
internalRouter.post(
  "/payments/by-order/:orderId/refund",
  params,
  asyncHandler(async (req, res) => {
    const cur = await pool.query("SELECT id, status FROM payments WHERE order_id = $1 AND status IN ('APPROVED','REFUNDED') ORDER BY created_at DESC LIMIT 1", [req.params.orderId]);
    if (!cur.rows[0]) return res.json({ status: "NOT_APPLICABLE" });
    if (cur.rows[0].status === "APPROVED") {
      await pool.query("UPDATE payments SET status = 'REFUNDED', updated_at = now() WHERE id = $1", [cur.rows[0].id]);
    }
    res.json({ status: "REFUNDED" });
  })
);
