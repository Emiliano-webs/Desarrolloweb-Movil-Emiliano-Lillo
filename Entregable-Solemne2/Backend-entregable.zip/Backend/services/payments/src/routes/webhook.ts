import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { HttpError, asyncHandler } from "@shared/errors";
import { env } from "@shared/env";
import { callService } from "@shared/internal";
import { limiter } from "@shared/http";
import { tx } from "@shared/db";
import { pool } from "../db";

export const webhookRouter = Router();

const eventSchema = z
  .object({
    eventId: z.string().min(3).max(100),
    paymentId: z.string().min(3).max(100),
    status: z.enum(["APPROVED", "REJECTED"]),
    amount: z.number().int().positive(),
    currency: z.string().length(3),
  })
  .strict();

const TOLERANCE_SECONDS = 300; // anti-replay: máximo 5 minutos de diferencia

function validSignature(req: any): boolean {
  const ts = Number(req.header("x-timestamp"));
  const header = String(req.header("x-signature") ?? "");
  const raw: Buffer | undefined = req.rawBody;
  if (!Number.isInteger(ts) || !raw || !header.startsWith("sha256=")) return false;
  if (Math.abs(Date.now() / 1000 - ts) > TOLERANCE_SECONDS) return false;

  // La firma cubre timestamp + cuerpo EXACTO recibido (bytes originales)
  const expected = createHmac("sha256", env("PAYMENT_WEBHOOK_SECRET")).update(`${ts}.`).update(raw).digest("hex");
  const given = header.slice("sha256=".length);
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(given, "hex");
  return a.length === b.length && timingSafeEqual(a, b); // comparación en tiempo constante
}

// ---------- S26 Webhook de la pasarela (sin JWT: se autentica con la firma HMAC) ----------
webhookRouter.post(
  "/payments",
  limiter(60_000, 100),
  asyncHandler(async (req, res) => {
    if (!validSignature(req)) throw new HttpError(401, "INVALID_SIGNATURE", "Firma inválida o expirada");

    const ev = eventSchema.parse(req.body);
    const payloadHash = createHash("sha256").update((req as any).rawBody).digest("hex");

    // Todo en una transacción: si algo falla, el evento no queda registrado y el proveedor puede reintentar
    const result = await tx(pool, async (c) => {
      // 1) Idempotencia: un eventId ya recibido no se procesa de nuevo
      const ins = await c.query(
        "INSERT INTO webhook_events (event_id, payment_id, payload_hash, result) VALUES ($1,$2,$3,'PROCESSING') ON CONFLICT (event_id) DO NOTHING",
        [ev.eventId, ev.paymentId, payloadHash]
      );
      if (!ins.rowCount) return { duplicate: true };

      let outcome: string;
      const p = (await c.query("SELECT * FROM payments WHERE id = $1 FOR UPDATE", [ev.paymentId])).rows[0];
      if (!p) outcome = "UNKNOWN_PAYMENT";
      else if (p.status !== "PENDING") outcome = "IGNORED_NOT_PENDING";
      else if (ev.amount !== p.amount || ev.currency !== p.currency) {
        // 2) El monto lo decide el backend: si no coincide con el total del pedido, NO se confirma
        await c.query("UPDATE payments SET status = 'AMOUNT_MISMATCH', updated_at = now() WHERE id = $1", [p.id]);
        outcome = "AMOUNT_MISMATCH";
      } else if (ev.status === "REJECTED") {
        await c.query("UPDATE payments SET status = 'REJECTED', updated_at = now() WHERE id = $1", [p.id]);
        outcome = "REJECTED";
      } else {
        // 3) Aprobado y verificado: solo este servicio puede mover el pedido a PAID (llamada idempotente)
        const r = await callService("orders", env("ORDERS_URL"), `/internal/orders/${p.order_id}/mark-paid`, { method: "POST", cid: req.cid });
        if (r.status !== 200) throw new HttpError(503, "DEPENDENCY_UNAVAILABLE", "No se pudo actualizar el pedido; reintenta la notificación");
        await c.query("UPDATE payments SET status = 'APPROVED', updated_at = now() WHERE id = $1", [p.id]);
        outcome = "APPROVED";
      }
      await c.query("UPDATE webhook_events SET result = $2 WHERE event_id = $1", [ev.eventId, outcome]);
      return { duplicate: false, outcome };
    });

    res.json({ received: true, ...(result.duplicate ? { duplicate: true } : {}) });
  })
);
