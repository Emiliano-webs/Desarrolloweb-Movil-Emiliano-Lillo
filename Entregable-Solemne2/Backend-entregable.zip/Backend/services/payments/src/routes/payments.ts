import { randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { authenticate, requireRole } from "@shared/auth";
import { HttpError, asyncHandler, conflict, notFound } from "@shared/errors";
import { env } from "@shared/env";
import { callService } from "@shared/internal";
import { validate } from "@shared/validate";
import { pool } from "../db";

export const paymentsRouter = Router();
paymentsRouter.use(authenticate, requireRole("CLIENTE"));
const orderIdSchema = z.string().regex(/^o-\d{8}-\d{6}$/);

const dto = (p: any) => ({ paymentId: p.id, orderId: p.order_id, status: p.status, updatedAt: p.updated_at });

// ---------- S25 Iniciar pago: el cliente NO envía monto, se toma del total guardado en el pedido ----------
paymentsRouter.post(
  "/",
  validate(z.object({ orderId: orderIdSchema }).strict()), // amount / status => 400
  asyncHandler(async (req, res) => {
    const { orderId } = req.body;
    const r = await callService("orders", env("ORDERS_URL"), `/internal/orders/${orderId}`, { cid: req.cid });
    if (r.status === 404) throw notFound("Pedido no encontrado");
    if (r.status !== 200) throw new HttpError(502, "DEPENDENCY_ERROR", "No se pudo consultar el pedido");
    const order = r.data;

    // El pedido debe ser del cliente autenticado (si no, se responde como si no existiera)
    if (order.customerId !== req.user!.sub) throw notFound("Pedido no encontrado");
    if (order.status !== "PENDING_PAYMENT") throw conflict("INVALID_STATE", `El pedido está en estado ${order.status}`, { status: order.status });

    const active = await pool.query("SELECT * FROM payments WHERE order_id = $1 AND status IN ('PENDING','APPROVED')", [orderId]);
    if (active.rows[0]) {
      if (active.rows[0].status === "APPROVED") throw conflict("INVALID_STATE", "El pedido ya fue pagado");
      return res.json({ ...dto(active.rows[0]), checkoutUrl: checkoutUrl(active.rows[0].id) }); // reintento: mismo pago pendiente
    }

    const id = `pay-${randomUUID()}`;
    const { rows } = await pool.query(
      "INSERT INTO payments (id, order_id, customer_id, amount, currency, status) VALUES ($1,$2,$3,$4,$5,'PENDING') RETURNING *",
      [id, orderId, req.user!.sub, order.total, order.currency]
    );
    res.status(201).json({ ...dto(rows[0]), checkoutUrl: checkoutUrl(id) });
  })
);

// URL de la pasarela de pruebas (en una integración real la entrega el proveedor)
const checkoutUrl = (paymentId: string) => `${process.env.PAYMENT_PROVIDER_URL ?? "https://pasarela.example"}/checkout/${paymentId}`;

// ---------- S25b Consultar estado (solo lectura; el estado lo decide el webhook) ----------
paymentsRouter.get(
  "/:orderId",
  validate(z.object({ orderId: orderIdSchema }), "params"),
  asyncHandler(async (req, res) => {
    const { rows } = await pool.query("SELECT * FROM payments WHERE order_id = $1 AND customer_id = $2 ORDER BY created_at DESC LIMIT 1", [
      req.params.orderId,
      req.user!.sub,
    ]);
    if (!rows[0]) throw notFound("Pago no encontrado"); // también cuando el pedido es de otro cliente
    res.json(dto(rows[0]));
  })
);
