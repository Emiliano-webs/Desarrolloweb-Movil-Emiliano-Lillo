import { env } from "./env";
import { HttpError } from "./errors";

// Llamada de un servicio a otro (rutas /internal/*): token de servicio, correlación y plazo máximo
export async function callService<T = any>(
  name: string,
  baseUrl: string,
  path: string,
  opts: { method?: string; body?: unknown; cid?: string; timeoutMs?: number } = {}
): Promise<{ status: number; data: T }> {
  let res: Response;
  try {
    res = await fetch(baseUrl + path, {
      method: opts.method ?? "GET",
      headers: {
        "content-type": "application/json",
        "x-service-token": env("SERVICE_TOKEN"),
        ...(opts.cid ? { "x-correlation-id": opts.cid } : {}),
      },
      body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
      signal: AbortSignal.timeout(opts.timeoutMs ?? 3000),
    });
  } catch {
    throw new HttpError(503, "DEPENDENCY_UNAVAILABLE", `El servicio ${name} no está disponible`);
  }
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin cuerpo */
  }
  return { status: res.status, data };
}
