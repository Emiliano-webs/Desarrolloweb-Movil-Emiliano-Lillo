import type { RequestHandler } from "express";
import { z, type ZodTypeAny } from "zod";

// Valida con lista blanca: los esquemas usan .strict(), así que un campo desconocido (ej. "total") da 400
export const validate =
  (schema: ZodTypeAny, source: "body" | "query" | "params" = "body"): RequestHandler =>
  (req, _res, next) => {
    const r = schema.safeParse(req[source]);
    if (!r.success) return next(r.error);
    (req as any)[source] = r.data;
    next();
  };

export const pageQuery = {
  page: z.coerce.number().int().min(1).default(1),
  size: z.coerce.number().int().min(1).max(50).default(20),
};
