export type Role = "CLIENTE" | "ADMIN" | "CAJERO" | "DESPACHO";
export interface AuthUser {
  sub: string;
  role: Role;
  jti: string;
}

declare global {
  namespace Express {
    interface Request {
      cid: string;
      user?: AuthUser;
    }
  }
}
