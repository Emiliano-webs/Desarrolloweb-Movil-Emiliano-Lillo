import type { NextFunction, Request, RequestHandler, Response } from "express";
import { ZodError } from "zod";

export class HttpError extends Error {
  status: number;
  code: string;
  extra: Record<string, unknown>;
  constructor(status: number, code: string, message: string, extra: Record<string, unknown> = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

export const unauthorized = (m = "Autenticación requerida") => new HttpError(401, "UNAUTHORIZED", m);
export const forbidden = (m = "No tienes permisos para esta operación") => new HttpError(403, "FORBIDDEN", m);
export const notFound = (m = "Recurso no encontrado") => new HttpError(404, "NOT_FOUND", m);
export const conflict = (code: string, m: string, extra: Record<string, unknown> = {}) => new HttpError(409, code, m, extra);
export const badRequest = (m: string, code = "VALIDATION_ERROR") => new HttpError(400, code, m);

// Express 4 no captura errores de funciones async: este envoltorio los pasa al manejador de errores
export const asyncHandler =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler =>
  (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };

export function errorHandler(err: any, req: Request, res: Response, _next: NextFunction) {
  if (err instanceof HttpError) {
    return res.status(err.status).json({ error: err.code, message: err.message, ...err.extra });
  }
  if (err instanceof ZodError) {
    const unknownKeys = err.issues
      .filter((i) => i.code === "unrecognized_keys")
      .flatMap((i) => ((i as any).keys as string[]) ?? []);
    if (unknownKeys.length > 0) {
      return res.status(400).json({
        error: "VALIDATION_ERROR",
        message: `Campos no permitidos: ${unknownKeys.join(", ")}`,
        fields: unknownKeys,
      });
    }
    return res.status(400).json({
      error: "VALIDATION_ERROR",
      message: "Datos inválidos",
      details: err.issues.map((i) => ({ field: i.path.join("."), message: i.message })),
    });
  }
  if (err?.type === "entity.parse.failed") {
    return res.status(400).json({ error: "INVALID_JSON", message: "El cuerpo no es un JSON válido" });
  }
  if (err?.type === "entity.too.large") {
    return res.status(413).json({ error: "PAYLOAD_TOO_LARGE", message: "El cuerpo es demasiado grande" });
  }
  if (err?.code === "23505") {
    return res.status(409).json({ error: "CONFLICT", message: "El recurso ya existe" });
  }
  // Nunca se registra el cuerpo ni cabeceras (pueden traer contraseñas o tokens)
  console.error(JSON.stringify({ level: "error", cid: req.cid, path: req.path, msg: err?.message }));
  return res.status(500).json({ error: "INTERNAL_ERROR", message: "Error interno" });
}
