import "./env";
import "./types";
import express, { type Express, type Request, type RequestHandler, type Response } from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { randomUUID } from "node:crypto";
import { errorHandler } from "./errors";

const tooMany = (_req: Request, res: Response) =>
  res.status(429).json({ error: "RATE_LIMITED", message: "Demasiadas peticiones, intenta más tarde" });

export function limiter(windowMs: number, limit: number, keyFn?: (req: Request) => string): RequestHandler {
  // Solo para la prueba de carga (npm run load): RATE_LIMIT_DISABLED=true desactiva los límites.
  // Se ignora si NODE_ENV=production. Debe quedar en false el resto del tiempo.
  if (process.env.RATE_LIMIT_DISABLED === "true" && process.env.NODE_ENV !== "production") {
    return (_req, _res, next) => next();
  }
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: true,
    legacyHeaders: false,
    handler: tooMany,
    ...(keyFn ? { keyGenerator: keyFn, validate: false } : {}),
  });
}

export function createApp(service: string, opts: { json?: boolean } = {}): Express {
  const app = express();
  app.disable("x-powered-by");
  app.use(helmet());

  // Identificador de correlación + registro de cada petición (sin cuerpo, sin query, sin cabeceras)
  app.use((req, res, next) => {
    const incoming = req.header("x-correlation-id");
    req.cid = incoming && /^[\w-]{8,64}$/.test(incoming) ? incoming : randomUUID();
    res.setHeader("x-correlation-id", req.cid);
    const t0 = Date.now();
    res.on("finish", () =>
      console.log(
        JSON.stringify({ svc: service, cid: req.cid, method: req.method, path: req.path, status: res.statusCode, ms: Date.now() - t0 })
      )
    );
    next();
  });

  app.use(limiter(60_000, 300));
  if (opts.json !== false) {
    app.use(
      express.json({
        limit: "100kb",
        // Se conserva el cuerpo crudo: el webhook necesita verificar la firma sobre los bytes originales
        verify: (req, _res, buf) => {
          (req as any).rawBody = buf;
        },
      })
    );
  }
  app.get("/health", (_req, res) => res.json({ service, status: "ok" }));
  return app;
}

export function finish(app: Express) {
  app.use((_req, res) => res.status(404).json({ error: "NOT_FOUND", message: "Ruta no encontrada" }));
  app.use(errorHandler);
}
