import { resolve } from "node:path";

// Carga .env desde la carpeta Backend (donde ejecutas npm). Node 20.12+ lo trae incluido.
try {
  (process as any).loadEnvFile(resolve(process.cwd(), ".env"));
} catch {
  /* si no existe .env, se usan las variables del sistema */
}

export function env(key: string, fallback?: string): string {
  const v = process.env[key] ?? fallback;
  if (v === undefined || v === "") throw new Error(`Falta la variable de entorno ${key} (revisa tu .env)`);
  return v;
}
