import "./env";
import "./types";
import type { RequestHandler } from "express";
import jwt from "jsonwebtoken";
import { createHash, timingSafeEqual } from "node:crypto";
import { env } from "./env";
import { forbidden, unauthorized } from "./errors";
import type { AuthUser, Role } from "./types";

let publicKeyCache: string | null = null;
const publicKey = () =>
  (publicKeyCache ??= Buffer.from(env("JWT_PUBLIC_KEY_B64"), "base64").toString("utf8"));

// Cada servicio valida el JWT por su cuenta (no hay gateway): firma RS256, emisor y expiración
export function verifyAccessToken(token: string): AuthUser {
  const p = jwt.verify(token, publicKey(), { algorithms: ["RS256"], issuer: "clients-service" }) as jwt.JwtPayload;
  return { sub: String(p.sub), role: p.role as Role, jti: String(p.jti) };
}

export const authenticate: RequestHandler = (req, _res, next) => {
  const m = /^Bearer (.+)$/.exec(req.header("authorization") ?? "");
  if (!m) return next(unauthorized());
  try {
    req.user = verifyAccessToken(m[1]);
    next();
  } catch {
    next(unauthorized("Token inválido o expirado"));
  }
};

export const requireRole =
  (...roles: Role[]): RequestHandler =>
  (req, _res, next) =>
    req.user && roles.includes(req.user.role) ? next() : next(forbidden());

// Rutas /internal/*: solo otros servicios con el token de servicio. Un JWT de usuario NO sirve aquí.
const digest = (s: string) => createHash("sha256").update(s).digest();
export const serviceAuth: RequestHandler = (req, _res, next) => {
  const given = req.header("x-service-token") ?? "";
  if (!timingSafeEqual(digest(given), digest(env("SERVICE_TOKEN")))) return next(unauthorized("Identidad de servicio requerida"));
  next();
};
