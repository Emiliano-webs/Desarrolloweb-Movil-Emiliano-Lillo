import "./env";
import { Pool, type PoolClient } from "pg";
import { env } from "./env";

export function createPool(prefix: "CLIENTS" | "INVENTORY" | "ORDERS" | "PAYMENTS"): Pool {
  return new Pool({
    host: process.env[`${prefix}_DB_HOST`] ?? "localhost",
    port: Number(env(`${prefix}_DB_PORT`)),
    user: env(`${prefix}_DB_USER`),
    password: env(`${prefix}_DB_PASSWORD`),
    database: env(`${prefix}_DB_NAME`),
    max: 10,
  });
}

export async function waitForDb(pool: Pool, tries = 30): Promise<void> {
  for (let i = 1; i <= tries; i++) {
    try {
      await pool.query("SELECT 1");
      return;
    } catch (e: any) {
      if (i === tries) throw e;
      console.log(`Esperando la base de datos (${i}/${tries})...`);
      await new Promise((r) => setTimeout(r, 1000));
    }
  }
}

export async function tx<T>(pool: Pool, fn: (c: PoolClient) => Promise<T>): Promise<T> {
  const c = await pool.connect();
  try {
    await c.query("BEGIN");
    const out = await fn(c);
    await c.query("COMMIT");
    return out;
  } catch (e) {
    await c.query("ROLLBACK");
    throw e;
  } finally {
    c.release();
  }
}
